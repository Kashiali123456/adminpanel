<!DOCTYPE html>
<html lang="en">
    <head>
        <title>Website - Custom Web N Logo Design</title>
        <?php
            require_once("include/head.php");
        ?>
        <link rel="stylesheet" href="css/inner-custom.css">
    </head>
    <body>
        <?php
            require_once("include/nav.php");
        ?> 
                <main>
            <section class="banner">
                <div class="banner-img">
                    <img src="inner/img/banner_web.jpg" alt="banner">
                </div>
                <div class="banner-content">
                    <div class="container">
                        <div class="row">
                            <div class="col-lg-6 col-12">
                                <div class="row">
                                    <div class="col">
                                        <img src="inner/img/seo-friendly.png" alt="responsive" class="w-auto">
                                    </div>
                                    <div class="col">
                                        <img src="inner/img/customized.png" alt="responsive" class="w-auto">
                                    </div>
                                    <div class="col">
                                        <img src="inner/img/responsive.png" alt="responsive" class="w-auto">
                                    </div>
                                    <div class="col-12">
                                        <div class="service-desc">
                                            <h2>
                                                Breathe Life into your Business!
                                                <span>Get a legitimate website made to establish a foothold in the market through custom web development services of a professional.</span>
                                            </h2>
                                            <button class="btn btn-rounded btn-white-outline">Learn More!</button>
                                            <div class="col-12 col-md-6 p-0">
                                                <a href="javascript:void(0);" class="btn btn-rounded btn-black popupBox d-lg-none d-block" data-toggle="modal" data-target="getQuote">Learn More!</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <?php
                                require_once("include/inner-top-form.php");
                            ?>
                        </div>
                    </div>
                </div>
            </section>
            <div id="exTab1">	
                <div class="middle-nav">
                        <ul class="nav nav-pills">
                            <li class="active">
                                <a  href="#1a" class="active" data-toggle="tab">web design</a>
                            </li>
                            <li>
                                <a href="#2a" data-toggle="tab">web package</a>
                            </li>
                            <li>
                                <a href="#3a" data-toggle="tab">web Process</a>
                            </li>
                            <li>
                                <a href="#4a" data-toggle="tab">faqs</a>
                            </li>
                        </ul>
                </div>
                <div class="tab-content clearfix">
                    <div class="tab-pane active" id="1a">
                            <!-- section one -->
            <section class="mt-5 pg whyUs"  data-aos="fade-up">
                <div class="container-fluid section-one">
                    <div class="row">
                        <div class="col-1 d-none d-xl-block">
                            <div class="about-heading">ABOUT<span>US</span></div>
                        </div>
                        <div class="col-xl-5 col-lg-6 mt-5">
                            <img width="100%" src="assets/section-one.png">
                        </div>
                        <div class="col-xl-5 col-lg-6 mt-5">
                            <div class="section-one-sec">
                            <h3>Custom Web Design in Houston TX</h3>
                            <div class="hr"></div>
                            <p class="color-lightgray section-one-p">
                                In the digital age where excess information freely flows through the channels of communication established by the internet, your business needs a platform of its own. A website is that platform that can give you the freedom to conduct business efficiently.<br>
The backend of the website is then developed using programming best practices and a scalable plan. So that when your business grows, your website has the ability to grow with you without limitations. After the development is complete, the website is tested for over a hundred measures of performance.<br>
Once the prototype is ready to rock the world, it rolls out the showroom with an SEO-friendly foundation and elements already incorporated. So that you can start raking in traffic from search engines without having to wait for the algorithms to find you in the deep abysses of the worldwide web.<br>
The keys are handed over to you with an integrated CMS so you can make changes, and add or remove content on your website easily without any knowledge of coding or scripting.

                            </p>
                            </div>
                            <div class="row section-one-box">
                                
                                <div class="col-xl-4 col-lg-6 col-sm-4">
                                <center>
                                <div class="section-one-box1">
                                    <img class="box-icon" src="assets/box-icon1.png">
                                </div>
                                <p>Attractive Design<img class="section-one-hr" src="assets/hr.png"></p>
                                </center>
                                </div>

                                <div class="col-xl-4 col-lg-6 col-sm-4">
                                <center>
                                <div class="section-one-box2">
                                    <img class="box-icon" src="assets/box-icon2.png">
                                </div>
                                <p>Immaculate Performance<img class="section-one-hr" src="assets/hr.png"></p>
                                </center>
                                </div>

                                <div class="col-xl-4 col-lg-12 col-sm-4">
                                <center>
                                <div class="section-one-box3 text-center">
                                    <img class="box-icon" src="assets/box-icon3.png">
                                </div>
                                <p>Engaging Content<img class="section-one-hr" src="assets/hr.png"></p>
                                
                                </center>
                                </div>
                            </div>
                        </div>
                        <div class="col-1 d-none d-xl-block">
                            <img width="90%" src="assets/section-one-icon.png">
                        </div>
                        <div class="col-12 text-center section-one-bottom">
                            CUSTOM WEB & LOGO
                        </div>
                    </div>
                </div>
            </section>
            <!-- section one end-->
                            <section class="pg glimpse" data-aos="fade-down">
                                <div class="container">
                                    <div class="row">
                                        <div class="col-12 text-center">
                                            <h2 class="title">Showcase</h2>
                                            <p>A glimpse of what we can accomplish for you!</p>
                                            <ul class="tabs d-none" id="glimpse">
                                                <li class="tab-link current" data-tab="tab-1">All</li>
                                                <li class="tab-link" data-tab="tab-2">2D Animations</li>
                                                <li class="tab-link" data-tab="tab-3">3D Animations</li>
                                                <li class="tab-link" data-tab="tab-4">Whiteboard Animations </li>
                                                <li class="tab-link" data-tab="tab-5">Typographic</li>
                                                <li class="tab-link" data-tab="tab-6">Explainer Videos </li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                                <div class="container-fluid">
                                    <div class="row">
                                        <div class="tab-content current" id="tab-1">
                                            <div class="workGal">
                                            <ul class="workList">
                                                <li class="first"><a href="inner/img/vd1.jpg" class="image-link"><i class="fa fa-search"></i></a><img src="inner/img/vd1.jpg" alt=""></li>
                                                <li><a href="inner/img/vd2.jpg" class="image-link"><i class="fa fa-search"></i></a><img src="inner/img/vd2.jpg" alt=""></li>
                                                <li><a href="inner/img/vd3.jpg" class="image-link"><i class="fa fa-search"></i></a><img src="inner/img/vd3.jpg" alt=""></li>
                                                <li><a href="inner/img/vd4.jpg" class="image-link"><i class="fa fa-search"></i></a><img src="inner/img/vd4.jpg" alt=""></li>
                                                <li><a href="inner/img/vd5.jpg" class="image-link"><i class="fa fa-search"></i></a><img src="inner/img/vd5.jpg" alt=""></li>
                                                <li><a href="inner/img/vd6.jpg" class="image-link"><i class="fa fa-search"></i></a><img src="inner/img/vd6.jpg" alt=""></li>
                                                <li><a href="inner/img/vd7.jpg" class="image-link"><i class="fa fa-search"></i></a><img src="inner/img/vd7.jpg" alt=""></li>
                                                <li><a href="inner/img/vd8.jpg" class="image-link"><i class="fa fa-search"></i></a><img src="inner/img/vd8.jpg" alt=""></li>
                                                <li><a href="inner/img/vd9.jpg" class="image-link"><i class="fa fa-search"></i></a><img src="inner/img/vd9.jpg" alt=""></li>
                                                <li class="last"><a href="inner/img/vd10.jpg" class="image-link"><i class="fa fa-search"></i></a><img src="inner/img/vd10.jpg" alt=""></li>
                                            </ul>
                                            </div>
                                        </div>
                                        <div class="tab-content" id="tab-2">
                                            <div class="workGal">
                                                <ul class="workList">
                                                    <li><img src="inner/img/vd1.jpg" alt=""></li>
                                                    <li><img src="inner/img/vd2.jpg" alt=""></li>
                                                    <li><img src="inner/img/vd8.jpg" alt=""></li>
                                                    <li><img src="inner/img/vd3.jpg" alt=""></li>
                                                    <li><img src="inner/img/vd4.jpg" alt=""></li>
                                                    <li><img src="inner/img/vd5.jpg" alt=""></li>
                                                    <li><img src="inner/img/vd6.jpg" alt=""></li>
                                                    <li><img src="inner/img/vd7.jpg" alt=""></li>
                                                    <li><img src="inner/img/vd9.jpg" alt=""></li>
                                                    <li><img src="inner/img/vd10.jpg" alt=""></li>
                                                </ul>
                                            </div>
                                        </div>  
                                        <div class="tab-content" id="tab-3">
                                            <div class="workGal">
                                                <ul class="workList">
                                                    <li><img src="inner/img/vd1.jpg" alt=""></li>
                                                    <li><img src="inner/img/vd2.jpg" alt=""></li>
                                                    <li><img src="inner/img/vd3.jpg" alt=""></li>
                                                    <li><img src="inner/img/vd4.jpg" alt=""></li>
                                                    <li><img src="inner/img/vd5.jpg" alt=""></li>
                                                    <li><img src="inner/img/vd6.jpg" alt=""></li>
                                                    <li><img src="inner/img/vd7.jpg" alt=""></li>
                                                    <li><img src="inner/img/vd8.jpg" alt=""></li>
                                                    <li><img src="inner/img/vd9.jpg" alt=""></li>
                                                    <li><img src="inner/img/vd10.jpg" alt=""></li>
                                                </ul>
                                            </div>
                                        </div>
                                        <div class="tab-content" id="tab-4">
                                            <div class="workGal">
                                                <ul class="workList">
                                                    <li><img src="inner/img/vd1.jpg" alt=""></li>
                                                    <li><img src="inner/img/vd2.jpg" alt=""></li>
                                                    <li><img src="inner/img/vd8.jpg" alt=""></li>
                                                    <li><img src="inner/img/vd3.jpg" alt=""></li>
                                                    <li><img src="inner/img/vd4.jpg" alt=""></li>
                                                    <li><img src="inner/img/vd5.jpg" alt=""></li>
                                                    <li><img src="inner/img/vd6.jpg" alt=""></li>
                                                    <li><img src="inner/img/vd7.jpg" alt=""></li>
                                                    <li><img src="inner/img/vd9.jpg" alt=""></li>
                                                    <li><img src="inner/img/vd10.jpg" alt=""></li>
                                                </ul>
                                            </div>
                                        </div>  
                                        <div class="tab-content" id="tab-5">
                                            <div class="workGal">
                                                <ul class="workList">
                                                    <li><img src="inner/img/vd1.jpg" alt=""></li>
                                                    <li><img src="inner/img/vd2.jpg" alt=""></li>
                                                    <li><img src="inner/img/vd3.jpg" alt=""></li>
                                                    <li><img src="inner/img/vd4.jpg" alt=""></li>
                                                    <li><img src="inner/img/vd5.jpg" alt=""></li>
                                                    <li><img src="inner/img/vd6.jpg" alt=""></li>
                                                    <li><img src="inner/img/vd7.jpg" alt=""></li>
                                                    <li><img src="inner/img/vd8.jpg" alt=""></li>
                                                    <li><img src="inner/img/vd9.jpg" alt=""></li>
                                                    <li><img src="inner/img/vd10.jpg" alt=""></li>
                                                </ul>
                                            </div>
                                        </div>
                                        <div class="tab-content" id="tab-6">
                                            <div class="workGal">
                                                <ul class="workList">
                                                    <li><img src="inner/img/vd1.jpg" alt=""></li>
                                                    <li><img src="inner/img/vd2.jpg" alt=""></li>
                                                    <li><img src="inner/img/vd8.jpg" alt=""></li>
                                                    <li><img src="inner/img/vd3.jpg" alt=""></li>
                                                    <li><img src="inner/img/vd4.jpg" alt=""></li>
                                                    <li><img src="inner/img/vd5.jpg" alt=""></li>
                                                    <li><img src="inner/img/vd6.jpg" alt=""></li>
                                                    <li><img src="inner/img/vd7.jpg" alt=""></li>
                                                    <li><img src="inner/img/vd9.jpg" alt=""></li>
                                                    <li><img src="inner/img/vd10.jpg" alt=""></li>
                                                </ul>
                                            </div>
                                        </div>                                       
                                    </div>
                                </div>
                            </section>
                            <section class="pg" data-aos="fade-up">
                                <div class="container">
                                    <div class="row">
                                        <div class="col-12">
                                            <ul class="list-center">
                                                <li><a href="#" class="btn btn-rounded btn-black btn-block btn-lg popupBox">lets get started</a></li>
                                                <li><a href="#" class="btn btn-rounded btn-white-outline active chatt btn-lg">chat now</a></li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </section>
                            <section class="pg" data-aos="fade-down">
                                <div class="simplerSol">
                                    <div class="container">
                                        <div class="row">
                                            <div class="col-md-12">
                                                <div class="text-center">
                                                    <h2 class="title">Elegant Solutions For All</h2>
                                                    <p>Each website can be tailored to meet the requirements of all types of business.</p>
                                                </div>
                                            </div>
                                        </div>
                                        <div id="serviceSlider">
                                            <div class="ss-slider">
                                                <div class="row">
                                                    <div class="col-md-6">
                                                        <h3>CUSTOM WEBSITE</h3>
                                                        <p>Your website is a reflection of your business and a poorly designed website will impede in reaching the full potential of your company. You need custom web development services because bland and generic websites do not take advantage of the digital platform. A unique business needs a unique design to be able to catch the attention of clients. This interactive portal can be made compatible with every single device out there and serve as a benchmark for the future growth of your business.
                                                        </p>
                                                        <p>
                                                            The Creative and Imaginative web designers of CusomWebnDesignLogos can make your wildest visions of a website into a fully functional and easy-to-operate reality. Our team always delivers products that blow client expectations out of the water. So you can rest assured and trust our capable hands.
                                                        </p>
                                                        <ul class="arrow-list">
                                                            <li>Unique Design.</li>
                                                            <li>Engaging Content.</li>
                                                            <li>Cross-Platform ompatibility.</li>
                                                            <li>Great User-Interface.</li>
                                                        </ul>
                                                    </div>
                                                    <div class="col-md-6">
                                                        <img src="inner/img/CW.jpg" alt="ss">
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="ss-slider">
                                                <div class="row">
                                                    <div class="col-md-6">
                                                        <h3>SEO Optimized Website</h3>
                                                        <p>
                                                            Each website needs a strong foundation of backend development to launch and it is during this prime time that we can optimize our website to rank high in every search engine so that every time a client searches for a particular service, they will always come towards your website. A website built on an SEO-optimized foundation will find itself in a much secure ranking than others. You also save a lot of money if you work now on SEO rather than much later when the website is already made. It is wise to use your website to gather as many clients as you can and CustomWebnDesignLogos are there to help you in this task.
                                                        </p>
                                                        <ul class="arrow-list">
                                                            <li>High-ranking of Website on search engines.</li>
                                                            <li>Attract Potential clients with ease.</li>
                                                            <li>Increase Growth of Business.</li>
                                                            <li>Ensure that your website is optimized through local SEO, Houston, Dallas, Austin and all over Texas.</li>
                                                        </ul>
                                                    </div>
                                                    <div class="col-md-6">
                                                        <img src="inner/img/CSW.jpg" alt="ss">
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="ss-slider">
                                                <div class="row">
                                                    <div class="col-md-6">
                                                        <h3>Content Management Systems</h3>
                                                        <p>
                                                           As a company evolves and changes, its online platform must also evolve and adapt to the times. That means updating and reworking your web content every so often to stay relevant. But hiring a web designer just to make a few changes is a tedious and expensive task.
                                                            </p>
                                                            <p>But CustomWebnDesignLogos is here for you and can make a Content Management System (CMS) for you so that you can update your website and make media changes whenever you like, wherever you like. Our systems will help your firm stay relevant throughout its commercial lifespan.
 
                                                        </p>
                                                        <ul class="arrow-list">
                                                            <li>Responsive.</li>
                                                            <li>Quick.</li>
                                                            <li>Improved User-Interface.</li>
                                                            <li>Efficient.</li>
                                                        </ul>
                                                    </div>
                                                    <div class="col-md-6">
                                                        <img src="inner/img/CMS.jpg" alt="ss">
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="ss-slider">
                                                <div class="row">
                                                    <div class="col-md-6">
                                                        <h3>E-Commerce Websites</h3>
                                                        <p>In this digital age, it is borderline commercial suicide not to invest in establishing your hold on the Internet. So many businesses and stores have gone virtual and online that not offering online services is considered a negative point. Especially if you are running a retail store or selling products, It is essential that you provide customers who are geographically separated from your business access to your product.</p> <p>
                                                        And so, CustomWebnDesignLogos can make an e-commerce store for your business on your website. Making it user-friendly, easy to search, displaying product variety, shopping cart functionality, and integrating flexible payment options. All sorts of businesses can be supported by E-commerce Websites like B2B, B2C, C2B, and C2C.

                                                        </p>
                                                        <ul class="arrow-list">
                                                            <li>Positive User Experience.</li>
                                                            <li>Cross-Platform Compatibility.</li>
                                                            <li>Visually Attractive Aesthetic to attract customers.</li>
                                                            <li>Constant Upgrade and Updating Service.</li>
                                                        </ul>
                                                    </div>
                                                    <div class="col-md-6">
                                                        <img src="inner/img/CMS.jpg" alt="ss">
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>    
                                </div>
                            </section>
                    </div>
                    <div class="tab-pane" id="2a">
                            <div class="pg secretDelievery" data-aos="fade-up">
                                <div class="container">
                                    <div class="row">
                                        <div class="col-12">
                                            <h2 class="title">LOOKING FOR <b>CUSTOM WEB DEVELOPMENT SERVICES?</b></h2>
                                            <p>Our firm prides itself in making quality websites that are guaranteed to meet your requirements and go further beyond. </p>
                                            <ul class="creativity">
                                                <li>
                                                    <div class="quote" style="background-image: url('inner/img/revision.png');">
                                                        <i>
                                                            <img src="inner/img/revision.png" alt="quote">
                                                        </i>
                                                        <p>Unlimited Revisions</p>
                                                    </div>
                                                </li>
                                                <li>
                                                    <div class="quote" style="background-image: url('inner/img/ownership.png');">
                                                        <i>
                                                            <img src="inner/img/ownership.png" alt="quote">
                                                        </i>
                                                        <p>100% Ownership Rights</p>
                                                    </div>
                                                </li>
                                                <li>
                                                    <div class="quote" style="background-image: url('inner/img/moneyBack.png');">
                                                        <i>
                                                            <img src="inner/img/moneyBack.png" alt="quote">
                                                        </i>
                                                        <p>100% Money Back Guarantee</p>
                                                    </div>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>
                           <!--section package -->
            <section class="package">
                <div class="text-center">
                    <h2>Web Development Packages</h2>
                        <p>Check out our web development packages according to your needs and budget constraints. We are sure to offer an economical and efficient solution.</p>
                        <?php
                            require_once("package/website-package.php");
                        ?>
                </div>
            </section>
            <!--section package end -->
            <br><br>
            <?php
                require_once("include/key.php");
            ?>
                    </div>
                    <div class="tab-pane" id="3a">
                            <div class="pg secretDelievery" data-aos="fade-up">
                                <div class="container">
                                    <div class="row">
                                        <div class="col-md-12 text-center">
                                            <h2 class="title">Hello Houston! Seo Services at your Disposal!</h2>
                                            <p>We’ll walk you through our custom web development services that deliver exceptional websites.</p>
                                            <ul class="list-center">
                                                <li>
                                                    <i class="sprite_1 sprite-sQ"></i>
                                                    <h4>Questionnaire</h4>
                                                    <p>Fill out a simple questionnaire that provides all information related to your business and its nature of work. </p>
                                                </li>
                                                <li>
                                                    <i class="sprite_1 sprite-appD"></i>
                                                    <h4>Test Designs</h4>
                                                    <p>You’ll receive a mock-up of your website shortly after placing your order.</p>
                                                </li>
                                                <li>
                                                    <i class="sprite_1 sprite-dR"></i>
                                                    <h4>Backend Development</h4>
                                                    <p>After a design has been settled we’ll work backstage on the website to optimize its performance, building a strong SEO foundation, and making it adaptable to the evolution of your firm.</p>
                                                </li>
                                                <li>
                                                    <i class="sprite_1 sprite-oO"></i>
                                                    <h4>Revisions Galore!</h4>
                                                    <p>If there is anything that you dislike about the website, you’ll find our developers to be very cooperative to make sure you get the website you always dreamed of.</p>
                                                </li>
                                                <li>
                                                    <i class="sprite_1 sprite-pD"></i>
                                                    <h4>Handover!</h4>
                                                    <p>The website is complete and will go live before being tested through multiple simulations and trials to uncover any hidden bugs or errors that need to be resolved.</p>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>
                    </div>
                    <div class="tab-pane" id="4a">
                            <div class="pg secretDelievery" data-aos="fade-down">
                                <div class="container">
                                    <div class="row">
                                        <div class="col-md-12 text-center">
                                            <h2 class="title">FAQS</h2>
                                            <p>
                                                For All Your General Queries, Go Through Our Detailed FAQS.
                                            </p>
                                            <ul class="arrow-list">
                                                <li class="first">
                                                    <h4>Do I own my website?</h4>
                                                    <p>Yes. Once you pay for you project, you get the complete ownership of your website, including the content, codes and source files. You own everything.
                                                    </p>
                                                </li>
                                                <li>
                                                    <h4>Can I resell or revamp my website?</h4>
                                                    <p>Once the project is yours, you have complete authority to do as you please.</p>
                                                </li>
                                                <li>
                                                    <h4>Do I have to provide the hosting server for my website?</h4>
                                                    <p>It depends on the package you have selected.</p>
                                                </li>
                                                <li>
                                                    <h4>Do you provide content writing services?</h4>
                                                    <p>Yes. If you need professional and SEO friendly content for your website, you've come to the right place.</p>
                                                </li>
                                                <li class="last">
                                                    <h4>How long does it take to get my website running?</h4>
                                                    <p>Depends on the nature of your website but usually it takes our experts around 2 to 3 weeks.</p>
                                                </li>
                                                
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>
                    </div>
                </div>
        <?php
            require_once("include/inner-counter.php");
            require_once("include/contact.php");
            require_once("include/client.php");
        ?>
        </main>
        <!--subscribe-->
<form method="post" id="sub">
            <section class="subscribe container-fluid">
                <div class="container">
                    <div class="row">
                        <div class="col-xl-5 text-center">
                            <h3>Looking for the finest web development company, Houston, Texas? Here we are.</h3>
                        </div>
                        <div class="col-xl-7">
                            <div class="input-container">
                                <i class="fa fa-envelope-o sub-icon" aria-hidden="true"></i>
                                <input name="email" class="input-field" type="email" placeholder="Enter Email Address..." required>
                                <div class="sub-btn-back">
                                <input  class="sub-btn" type="submit" name="" value="LET'S START"></div>
                               
                            </div>

                        </div>
                    </div>
                </div>
            </section>

             </form>
            <!--subscribe end-->
        <?php
            require_once("include/footer.php");
            require_once("include/script.php");
        ?>
</body>
</html>    
    <script>
        $(window).bind('load resize', function () {
                    // $('#parent').append('<div>hello</div>');    
                    var viewWidth = $(window).width();
                    if(viewWidth > 767){
                        $('#serviceSlider').on('afterChange', function(slick, currentSlide){
                        var get_index = currentSlide.currentSlide;
                        switch(get_index){
                            case 0:
                                $(this).find('img').after('<img src="inner/img/CW-bg.png" class="bg-img">');
                                break;
                            case 1:
                                $(this).find('img').after('<img src="inner/img/CW-bg.png" class="bg-img">');
                                break;
                            case 2:
                                $(this).find('img').after('<img src="inner/img/CMS-bg.png" class="bg-img">');
                                break;
                            case 3:
                                $(this).find('img').after('<img src="inner/img/ECOM-bg.png" class="bg-img">');
                                break;
                            case 4:
                                $(this).find('img').after('<img src="inner/img/CW-bg.png" class="bg-img">');
                                break;
                        }
                        });
                        $('#serviceSlider').on('beforeChange', function (slick, currentSlide, nextSlide) {
                            var get_index = currentSlide.currentSlide;
                            switch(get_index){
                                case 0:
                                    $(this).find('img.bg-img').remove();
                                    break;
                                case 1:
                                    $(this).find('img.bg-img').remove();
                                    break;
                                case 2:
                                    $(this).find('img.bg-img').remove();
                                    break;
                                case 3:
                                    $(this).find('img.bg-img').remove();
                                    break;
                                case 4:
                                    $(this).find('img.bg-img').remove();
                                    break;
                            }                          
                        });
                        $('#serviceSlider').find('img').after('<img src="inner/img/CW-bg.png" class="bg-img">');
                    }
                })
    </script>