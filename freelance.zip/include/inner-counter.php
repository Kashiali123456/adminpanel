<section class="mountain">
                <div class="container">
                    <div class="row">
                        <div class="col-12">
                            <ul class="mountainNum">
                                <li>
                                    <h2>Join the list of Custom WebnLogo Designs’ satisfied customers.</h2>
                                </li>
                                <li><h4><strong class="count-num">5678</strong>SATISFIED CUSTOMER</h4></li>
                                <li><h4><strong class="count-num">9892</strong>PROJECTS COMPLETED</h4></li>
                                <li><h4><strong class="count-num">1015</strong>DAILY VISITS</h4></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </section>