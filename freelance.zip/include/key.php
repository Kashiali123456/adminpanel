<!--section five -->
			<section class="container-fluid section-five">
				<div class="container ">

					<div class="row text-center">
						<div class="col-12">
						<h3>KEY <b>FEATURES</b></h3>
						</div>
					<div class="col-lg-2 col-md-4 col-6">
						<div class="five-img">
						<img src="assets/key/image1.png">
						</div>
						<p>100% Satisfaction Guaranteed</p>
					</div>
					<div class="col-lg-3 col-md-4 col-6">
						<div class="five-img">
						<img src="assets/key/image2.png">
						</div>
						<p>24/7 Customer Support</p>
					</div>
					<div class="col-lg-2 col-md-4 col-6">
						<div class="five-img">
						<img src="assets/key/image3.png">
						</div>
						<p>Digital Services Provider</p>
					</div>
					<div class="col-lg-3 col-md-6 col-6">
						<div class="five-img">
						<img src="assets/key/image4.png">
						</div>
						<p>Efficient and Speedy Delivery</p>
					</div>
					<div class="col-lg-2 col-md-6 col-12">
						<div class="five-img">
						<img src="assets/key/image5.png">
						</div>
						<p>Experienced & Creative Designers</p>
					</div>
					</div>
				</div>
			</section>
			<!--section five end -->