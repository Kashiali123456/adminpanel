<?php
  require_once("admin_panel/connection.php");
?>			
			<meta charset="utf-8">
			<meta http-equiv="X-UA-Compatible" content="IE=edge">
			<meta name="viewport" content="width=device-width, initial-scale=1">
      <link rel="shortcut icon" type="image/x-icon" href="assets/fav.ico">
			<link rel="stylesheet" href="inner/bootstrap/4.0.0/css/bootstrap.min.css">
			<link rel="stylesheet" type="text/css" href="fonts/pe-icon-7-stroke/css/pe-icon-7-stroke.css">
			<link rel="stylesheet" type="text/css" href="fonts/font-awesome/css/font-awesome.min.css">
			<link href="css/jquerysctipttop.css" rel="stylesheet" type="text/css">
  			<!-- Plugin -->
  			<link rel="stylesheet" type="text/css" href="css/plugin/owlcarousel/owl.theme.default.min.css">
  			<link rel="stylesheet" type="text/css" href="css/plugin/owlcarousel/owl.carousel.min.css">
        <!-- inner page-->
  			<link rel="stylesheet" href="inner/css/slick.css">
        <link rel="stylesheet" href="inner/css/intlTelInput.min.css">
        <link rel="stylesheet" href="inner/ajax/libs/animate.css/3.7.2/animate.min.css">
        <link rel="stylesheet" href="inner/css/jQuery-plugin-progressbar.css">
        <link rel="stylesheet" href="inner/css/web.min.css">
        <link rel="stylesheet" href="inner/css/magnific-popup.css">
        <link rel="stylesheet" href="inner/css/main.css">

        <!-- custom -->
            <link rel="stylesheet" type="text/css" href="css/style.css">
            <link rel="stylesheet" type="text/css" href="css/home-responsive.css">
			