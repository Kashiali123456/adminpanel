<!-- START mainslider REVOLUTION SLIDER 6.5.7 --><p class="rs-p-wp-fix"></p>
			<rs-module-wrap id="rev_slider_2_1_wrapper" data-alias="mainslider" data-source="gallery" style="visibility:hidden;background:transparent;padding:0;margin:0px auto;margin-top:0;margin-bottom:0;">
				<rs-module id="rev_slider_2_1" style="" data-version="6.5.7">
					<rs-slides>
						<rs-slide style="position: absolute;" data-key="rs-14" data-title="Slide" data-thumb="//localhost/wpslider/wp-content/uploads/2021/08/slidebg-1.png" data-duration="6000ms" data-anim="ms:600;f:center;" data-in="o:0;x:cyc(-10|10);y:cyc(-10|10);r:cyc(-10|10);sx:0.1;sy:0.1;row:8;col:8;" data-out="a:false;">
							<img src="assets/transparent.png" alt="Slide" title="Untitled" class="rev-slidebg tp-rs-img" data-bg="p:center top;c:linear-gradient(rgba(248,165,25,1) 0%, rgba(248,165,25,1) 63%, rgba(12,12,12,1) 100%);f:70% 100%;" data-no-retina>
<!--
							--><rs-layer
								id="slider-2-slide-14-layer-1" 
								data-type="text"
								data-rsp_ch="on"
								data-xy="x:l,l,c,c;xo:8px,20px,1px,0;yo:210px,171px,320px,265px;"
								data-text="w:normal;s:62,50,58,46;l:64,50,55,44;ls:4px,3px,3px,1px;fw:700;a:left,left,center,center;"
								data-dim="w:auto,519px,auto,auto;h:141px,107px,175px,95px;"
								data-frame_0="x:-100%;y:0,0,0px,0px;"
								data-frame_0_mask="u:t;x:0,0,0px,0px;y:0,0,0px,0px;"
								data-frame_1="x:0,0,0px,0px;y:0,0,0px,0px;st:300;sp:1000;sR:300;"
								data-frame_1_mask="u:t;x:0,0,0px,0px;y:0,0,0px,0px;"
								data-frame_999="x:-100%;o:0;st:5500;sp:500;"
								data-frame_999_mask="u:t;"
								style="z-index:10;font-family:'Roboto';"
							>Your One-Stop Shop <br />
Digital Solution! 
							</rs-layer><!--

							--><rs-layer
								id="slider-2-slide-14-layer-2" 
								data-type="text"
								data-rsp_ch="on"
								data-xy="x:l,l,c,c;xo:8px,20px,0,0;yo:342px,279px,438px,359px;"
								data-text="w:normal;s:25,24,20,20;l:31,25,24,28;ls:1px,0px,0px,0px;a:left,left,center,center;"
								data-dim="h:auto,53px,auto,auto;"
								data-frame_0="x:-100%;y:0,0,0px,0px;"
								data-frame_0_mask="u:t;x:0,0,0px,0px;y:0,0,0px,0px;"
								data-frame_1="x:0,0,0px,0px;y:0,0,0px,0px;st:300;sp:1000;sR:300;"
								data-frame_1_mask="u:t;x:0,0,0px,0px;y:0,0,0px,0px;"
								data-frame_999="x:-100%;o:0;st:5500;sp:500;"
								data-frame_999_mask="u:t;"
								style="z-index:11;font-family:'Roboto';"
							>Everything from Logo Design,<br>	Web Design and SEO Services in Houston, TX
							</rs-layer><!--

							--><rs-layer
								id="slider-2-slide-14-layer-3" 
								data-type="text"
								data-rsp_ch="on"
								data-xy="x:l,l,c,c;xo:8px,20px,0,0;yo:411px,339px,497px,420px;"
								data-text="w:normal;s:15,15,13,12;l:25,23,20,20;a:left,left,center,center;"
								data-dim="w:458px,435px,373px,399px;"
								data-frame_0="x:-100%;y:0,0px,0px,0px;"
								data-frame_0_mask="u:t;x:0,0px,0px,0px;y:0,0px,0px,0px;"
								data-frame_1="x:0,0px,0px,0px;y:0,0px,0px,0px;st:300;sp:1000;sR:300;"
								data-frame_1_mask="u:t;x:0,0px,0px,0px;y:0,0px,0px,0px;"
								data-frame_999="x:-100%;o:0;st:5500;sp:500;"
								data-frame_999_mask="u:t;"
								style="z-index:13;font-family:'Roboto';"
							>Custom Web n Logo Design is the best company for you, if you want to build your virtual stronghold. An online presence is necessity, if you seek to reach new heights.
							</rs-layer><!--

							--><a
								id="slider-2-slide-14-layer-4" 
								class="rs-layer rev-btn rev-hiddenicon"
								href="#" target="_self"
								data-type="button"
								data-rsp_ch="on"
								data-xy="x:l,l,c,c;xo:8px,21px,0,0;yo:498px,413px,565px,486px;"
								data-text="w:normal;s:17,16,14,15;l:37,30,30,32;ls:1px,0px,0px,0px;fw:700;a:left,left,center,center;"
								data-dim="minh:0px,none,none,none;"
								data-padding="t:12,10,11,11;r:35,29,30,32;b:12,10,11,11;l:35,29,30,32;"
								data-border="bor:30px,30px,30px,30px;"
								data-frame_0="x:-100%;y:0,0,0px,0px;"
								data-frame_0_mask="u:t;x:0,0,0px,0px;y:0,0,0px,0px;"
								data-frame_1="x:0,0,0px,0px;y:0,0,0px,0px;st:300;sp:1000;sR:300;"
								data-frame_1_mask="u:t;x:0,0,0px,0px;y:0,0,0px,0px;"
								data-frame_999="x:-100%;o:0;st:5500;sp:500;"
								data-frame_999_mask="u:t;"
								data-frame_hover="c:#000;bgc:#fff;bor:30px,30px,30px,30px;sp:200;"
								style="z-index:12;background-color:#042b48;font-family:'Roboto';text-transform:uppercase;"
							>LEt'S GET STARTED <i class="fa-chevron-right"></i> 
							</a><!--

							--><rs-layer
								id="slider-2-slide-14-layer-5" 
								data-type="image"
								data-rsp_ch="on"
								data-xy="x:l,l,c,c;xo:371px,296px,-62px,-52px;y:m;yo:-55px,-117px,-214px,-242px;"
								data-text="w:normal;s:20,16,12,7;l:0,20,15,9;"
								data-dim="w:870px,771px,737px,499px;h:447px,396px,379px,256px;"
								data-frame_0="x:100%;"
								data-frame_0_mask="u:t;"
								data-frame_1="st:700;sp:1100;sR:690;"
								data-frame_1_mask="u:t;"
								data-frame_999="x:100%;o:0;st:5500;sp:500;"
								data-frame_999_mask="u:t;"
								style="z-index:8;"
							><img src="assets/slideimg.png" class="tp-rs-img" width="1263" height="649" data-no-retina> 
							</rs-layer><!--
-->						</rs-slide>
						<rs-slide style="position: absolute;" data-key="rs-15" data-title="Slide" data-thumb="//localhost/wpslider/wp-content/uploads/2021/08/slidebg-1.png" data-duration="6000ms" data-anim="ms:600;f:center;" data-in="o:0;x:cyc(-10|10);y:cyc(-10|10);r:cyc(-10|10);sx:0.1;sy:0.1;row:8;col:8;" data-out="a:false;">
							<img src="assets/transparent.png" alt="Slide" title="Untitled" class="rev-slidebg tp-rs-img" data-bg="p:center top;c:linear-gradient(rgba(216,133,252,1) 0%, rgba(88,86,214,1) 100%);f:70% 100%;" data-no-retina>
<!--
							--><rs-layer
								id="slider-2-slide-15-layer-1" 
								data-type="text"
								data-rsp_ch="on"
								data-xy="x:l,l,c,c;xo:8px,20px,1px,0;yo:210px,171px,320px,265px;"
								data-text="w:normal;s:62,50,58,46;l:64,50,55,44;ls:4px,3px,3px,1px;fw:700;a:left,left,center,center;"
								data-dim="w:auto,519px,auto,auto;h:141px,107px,175px,95px;"
								data-frame_0="x:-100%;y:0,0,0px,0px;"
								data-frame_0_mask="u:t;x:0,0,0px,0px;y:0,0,0px,0px;"
								data-frame_1="x:0,0,0px,0px;y:0,0,0px,0px;st:300;sp:1000;sR:300;"
								data-frame_1_mask="u:t;x:0,0,0px,0px;y:0,0,0px,0px;"
								data-frame_999="x:-100%;o:0;st:5500;sp:500;"
								data-frame_999_mask="u:t;"
								style="z-index:10;font-family:'Roboto';"
							><!--Make your Mark! -->
							</rs-layer><!--

							--><rs-layer
								id="slider-2-slide-15-layer-2" 
								data-type="text"
								data-rsp_ch="on"
								data-xy="x:l,l,c,c;xo:8px,20px,0,0;yo:285px,231px,396px,323px;"
								data-text="w:normal;s:25,24,20,20;l:31,25,24,28;ls:1px,0px,0px,0px;a:left,left,center,center;"
								data-dim="h:auto,53px,auto,auto;"
								data-frame_0="x:-100%;y:0,0,0px,0px;"
								data-frame_0_mask="u:t;x:0,0,0px,0px;y:0,0,0px,0px;"
								data-frame_1="x:0,0,0px,0px;y:0,0,0px,0px;st:300;sp:1000;sR:300;"
								data-frame_1_mask="u:t;x:0,0,0px,0px;y:0,0,0px,0px;"
								data-frame_999="x:-100%;o:0;st:5500;sp:500;"
								data-frame_999_mask="u:t;"
								style="z-index:11;font-family:'Roboto';"
							>With the help of the best Web<br> design company in Houston, TX
							</rs-layer><!--

							--><rs-layer
								id="slider-2-slide-15-layer-3" 
								data-type="text"
								data-rsp_ch="on"
								data-xy="x:l,l,c,c;xo:8px,20px,0,0;yo:359px,294px,455px,388px;"
								data-text="w:normal;s:15,15,13,12;l:25,23,20,20;a:left,left,center,center;"
								data-dim="w:458px,435px,373px,399px;"
								data-frame_0="x:-100%;y:0,0px,0px,0px;"
								data-frame_0_mask="u:t;x:0,0px,0px,0px;y:0,0px,0px,0px;"
								data-frame_1="x:0,0px,0px,0px;y:0,0px,0px,0px;st:300;sp:1000;sR:300;"
								data-frame_1_mask="u:t;x:0,0px,0px,0px;y:0,0px,0px,0px;"
								data-frame_999="x:-100%;o:0;st:5500;sp:500;"
								data-frame_999_mask="u:t;"
								style="z-index:13;font-family:'Roboto';"
							>Custom Web n Logo Design company will build your flagship online to attract new and potential customers to your website and help your business grow exponentially! 
							</rs-layer><!--

							--><a
								id="slider-2-slide-15-layer-4" 
								class="rs-layer rev-btn rev-hiddenicon"
								href="#" target="_self"
								data-type="button"
								data-rsp_ch="on"
								data-xy="x:l,l,c,c;xo:8px,21px,0,-1px;yo:441px,375px,527px,437px;"
								data-text="w:normal;s:17,16,14,15;l:37,30,30,32;ls:1px,0px,0px,0px;fw:700;a:left,left,center,center;"
								data-dim="minh:0px,none,none,none;"
								data-padding="t:12,10,11,11;r:35,29,30,32;b:12,10,11,11;l:35,29,30,32;"
								data-border="bor:30px,30px,30px,30px;"
								data-frame_0="x:-100%;y:0,0,0px,0px;"
								data-frame_0_mask="u:t;x:0,0,0px,0px;y:0,0,0px,0px;"
								data-frame_1="x:0,0,0px,0px;y:0,0,0px,0px;st:300;sp:1000;sR:300;"
								data-frame_1_mask="u:t;x:0,0,0px,0px;y:0,0,0px,0px;"
								data-frame_999="x:-100%;o:0;st:5500;sp:500;"
								data-frame_999_mask="u:t;"
								data-frame_hover="c:#000;bgc:#fff;bor:30px,30px,30px,30px;sp:200;"
								style="z-index:12;background-color:#042b48;font-family:'Roboto';text-transform:uppercase;"
							>Learn More! <i class="fa-chevron-right"></i> 
							</a><!--

							--><rs-layer
								id="slider-2-slide-15-layer-5" 
								data-type="image"
								data-rsp_ch="on"
								data-xy="x:l,l,c,c;xo:371px,296px,-62px,-52px;y:m;yo:-55px,-117px,-214px,-242px;"
								data-text="w:normal;s:20,16,12,7;l:0,20,15,9;"
								data-dim="w:870px,771px,737px,499px;h:447px,396px,379px,256px;"
								data-frame_0="x:100%;"
								data-frame_0_mask="u:t;"
								data-frame_1="st:700;sp:1100;sR:690;"
								data-frame_1_mask="u:t;"
								data-frame_999="x:100%;o:0;st:5500;sp:500;"
								data-frame_999_mask="u:t;"
								style="z-index:8;"
							><img src="assets/slideimg.png" class="tp-rs-img" width="1263" height="649" data-no-retina> 
							</rs-layer><!--
-->						</rs-slide>
						<rs-slide style="position: absolute;" data-key="rs-16" data-title="Slide" data-thumb="//localhost/wpslider/wp-content/uploads/2021/08/slidebg-1.png" data-duration="6000ms" data-anim="ms:600;f:center;" data-in="o:0;x:cyc(-10|10);y:cyc(-10|10);r:cyc(-10|10);sx:0.1;sy:0.1;row:8;col:8;" data-out="a:false;">
							<img src="assets/transparent.png" alt="Slide" title="Untitled" class="rev-slidebg tp-rs-img" data-bg="p:center top;c:linear-gradient(rgba(1,186,191,1) 0%, rgba(127,126,214,1) 100%);f:70% 100%;" data-no-retina>
<!--
							--><rs-layer
								id="slider-2-slide-16-layer-1" 
								data-type="text"
								data-rsp_ch="on"
								data-xy="x:l,l,c,c;xo:8px,20px,1px,0;yo:210px,171px,320px,265px;"
								data-text="w:normal;s:62,50,58,46;l:64,50,55,44;ls:4px,3px,3px,1px;fw:700;a:left,left,center,center;"
								data-dim="w:auto,519px,auto,auto;h:141px,107px,175px,95px;"
								data-frame_0="x:-100%;y:0,0,0px,0px;"
								data-frame_0_mask="u:t;x:0,0,0px,0px;y:0,0,0px,0px;"
								data-frame_1="x:0,0,0px,0px;y:0,0,0px,0px;st:300;sp:1000;sR:300;"
								data-frame_1_mask="u:t;x:0,0,0px,0px;y:0,0,0px,0px;"
								data-frame_999="x:-100%;o:0;st:5500;sp:500;"
								data-frame_999_mask="u:t;"
								style="z-index:10;font-family:'Roboto';"
							><!--Become Iconic! -->
							</rs-layer><!--

							--><rs-layer
								id="slider-2-slide-16-layer-2" 
								data-type="text"
								data-rsp_ch="on"
								data-xy="x:l,l,c,c;xo:8px,20px,0,0;yo:250px,231px,396px,323px;"
								data-text="w:normal;s:25,24,20,20;l:31,25,24,28;ls:1px,0px,0px,0px;a:left,left,center,center;"
								data-dim="h:auto,53px,auto,auto;"
								data-frame_0="x:-100%;y:0,0,0px,0px;"
								data-frame_0_mask="u:t;x:0,0,0px,0px;y:0,0,0px,0px;"
								data-frame_1="x:0,0,0px,0px;y:0,0,0px,0px;st:300;sp:1000;sR:300;"
								data-frame_1_mask="u:t;x:0,0,0px,0px;y:0,0,0px,0px;"
								data-frame_999="x:-100%;o:0;st:5500;sp:500;"
								data-frame_999_mask="u:t;"
								style="z-index:11;font-family:'Roboto';"
							>The most inspired Custom Logo Design<br> Company in Houston, TX
							</rs-layer><!--

							--><rs-layer
								id="slider-2-slide-16-layer-3" 
								data-type="text"
								data-rsp_ch="on"
								data-xy="x:l,l,c,c;xo:7px,20px,0,1px;yo:324px,272px,439px,365px;"
								data-text="w:normal;s:15,15,13,12;l:25,23,20,20;a:left,left,center,center;"
								data-dim="w:458px,435px,373px,399px;"
								data-frame_0="x:-100%;y:0,0px,0px,0px;"
								data-frame_0_mask="u:t;x:0,0px,0px,0px;y:0,0px,0px,0px;"
								data-frame_1="x:0,0px,0px,0px;y:0,0px,0px,0px;st:300;sp:1000;sR:300;"
								data-frame_1_mask="u:t;x:0,0px,0px,0px;y:0,0px,0px,0px;"
								data-frame_999="x:-100%;o:0;st:5500;sp:500;"
								data-frame_999_mask="u:t;"
								style="z-index:13;font-family:'Roboto';"
							>We’ll forge you, a unique customized logo design for your company to attract new customers. 
							</rs-layer><!--

							--><a
								id="slider-2-slide-16-layer-4" 
								class="rs-layer rev-btn rev-hiddenicon"
								href="#" target="_self"
								data-type="button"
								data-rsp_ch="on"
								data-xy="x:l,l,c,c;xo:8px,21px,0,-2px;yo:384px,348px,499px,422px;"
								data-text="w:normal;s:17,16,14,15;l:37,30,30,32;ls:1px,0px,0px,0px;fw:700;a:left,left,center,center;"
								data-dim="minh:0px,none,none,none;"
								data-padding="t:12,10,11,11;r:35,29,30,32;b:12,10,11,11;l:35,29,30,32;"
								data-border="bor:30px,30px,30px,30px;"
								data-frame_0="x:-100%;y:0,0,0px,0px;"
								data-frame_0_mask="u:t;x:0,0,0px,0px;y:0,0,0px,0px;"
								data-frame_1="x:0,0,0px,0px;y:0,0,0px,0px;st:300;sp:1000;sR:300;"
								data-frame_1_mask="u:t;x:0,0,0px,0px;y:0,0,0px,0px;"
								data-frame_999="x:-100%;o:0;st:5500;sp:500;"
								data-frame_999_mask="u:t;"
								data-frame_hover="c:#000;bgc:#fff;bor:30px,30px,30px,30px;sp:200;"
								style="z-index:12;background-color:#042b48;font-family:'Roboto';text-transform:uppercase;"
							>Check us Out!<i class="fa-chevron-right"></i> 
							</a><!--

							--><rs-layer
								id="slider-2-slide-16-layer-5" 
								data-type="image"
								data-rsp_ch="on"
								data-xy="x:l,l,c,c;xo:371px,296px,-62px,-52px;y:m;yo:-55px,-117px,-214px,-242px;"
								data-text="w:normal;s:20,16,12,7;l:0,20,15,9;"
								data-dim="w:870px,771px,737px,499px;h:447px,396px,379px,256px;"
								data-frame_0="x:100%;"
								data-frame_0_mask="u:t;"
								data-frame_1="st:700;sp:1100;sR:690;"
								data-frame_1_mask="u:t;"
								data-frame_999="x:100%;o:0;st:5500;sp:500;"
								data-frame_999_mask="u:t;"
								style="z-index:8;"
							><img src="assets/slideimg.png" class="tp-rs-img" width="1263" height="649" data-no-retina> 
							</rs-layer><!--
-->						</rs-slide>
					</rs-slides>
					<rs-static-layers><!--

							--><rs-layer
								id="slider-2-slide-2-layer-11" 
								class="rs-layer-static"
								data-type="image"
								data-rsp_ch="on"
								data-xy="x:c;y:b;yo:-10px,-8px,-6px,-3px;"
								data-text="w:normal;s:20,16,12,7;l:0,20,15,9;"
								data-dim="w:1920px,1585px,1204px,742px;h:293px,241px,183px,112px;"
								data-onslides="s:1;"
								data-frame_999="o:0;st:w;"
								style="z-index:5;"
							><img src="assets/wavbg.png" class="tp-rs-img" width="2048" height="313" data-no-retina> 
							</rs-layer><!--
					--></rs-static-layers>
				</rs-module>
				<script type="text/javascript">
					
				</script>
<script type="text/javascript">
		if(typeof revslider_showDoubleJqueryError === "undefined") {function revslider_showDoubleJqueryError(sliderID) {console.log("You have some jquery.js library include that comes after the Slider Revolution files js inclusion.");console.log("To fix this, you can:");console.log("1. Set 'Module General Options' -> 'Advanced' -> 'jQuery & OutPut Filters' -> 'Put JS to Body' to on");console.log("2. Find the double jQuery.js inclusion and remove it");return "Double Included jQuery Library";}}
</script>
			</rs-module-wrap>
			<!-- END REVOLUTION SLIDER -->

				<script type="text/javascript">
					var	tpj = jQuery;
					if(window.RS_MODULES === undefined) window.RS_MODULES = {};
					if(RS_MODULES.modules === undefined) RS_MODULES.modules = {};
					RS_MODULES.modules["revslider21"] = {init:function() {
						window.revapi2 = window.revapi2===undefined || window.revapi2===null || window.revapi2.length===0  ? document.getElementById("rev_slider_2_1") : window.revapi2;
						if(window.revapi2 === null || window.revapi2 === undefined || window.revapi2.length==0) { window.revapi2initTry = window.revapi2initTry ===undefined ? 0 : window.revapi2initTry+1; if (window.revapi2initTry<20) requestAnimationFrame(function() {RS_MODULES.modules["revslider21"].init()}); return;}
						window.revapi2 = jQuery(window.revapi2);
						if(window.revapi2.revolution==undefined){ revslider_showDoubleJqueryError("rev_slider_2_1"); return;}
						revapi2.revolutionInit({
								revapi:"revapi2",
								DPR:"dpr",
								sliderLayout:"fullwidth",
								visibilityLevels:"1240,1024,778,480",
								gridwidth:"1240,1024,778,480",
								gridheight:"900,900,800,820",
								spinner:"spinner6",
								perspective:600,
								perspectiveType:"global",
								spinnerclr:"#f8a217",
								editorheight:"900,900,800,820",
								responsiveLevels:"1240,1024,778,480",
								progressBar:{disableProgressBar:true},
								navigation: {
									wheelCallDelay:1000,
									onHoverStop:false,
									touch: {
										touchenabled:true
									},
									/*arrows: {
										enable:true,
										style:"hesperiden",
										left: {
											h_offset:0
										},
										right: {
											h_offset:0
										}
									},*/
									bullets: {
										enable:true,
										tmp:"<span class=\"tp-bullet-inner\"></span>",
										style:"uranus",
										anim:"zoomin",
										h_align:"left",
										v_align:"center",
										h_offset:8,
										v_offset:155,
										space:8,
										container:"layergrid"
									}
								},
								viewPort: {
									global:false,
									globalDist:"-200px",
									enable:false
								},
								fallbacks: {
									allowHTML5AutoPlayOnAndroid:true
								},
						});
						
					}} // End of RevInitScript
					if (window.RS_MODULES.checkMinimal!==undefined) { window.RS_MODULES.checkMinimal();};
				</script>



<style type="text/css">#rev_slider_2_1_wrapper .hesperiden.tparrows{cursor:pointer;background:rgba(0,0,0,0.5);width:40px;height:40px;position:absolute;display:block;z-index:1000; border-radius:50%}#rev_slider_2_1_wrapper .hesperiden.tparrows.rs-touchhover{background:#000000}#rev_slider_2_1_wrapper .hesperiden.tparrows:before{font-family:'revicons';font-size:20px;color:#ffffff;display:block;line-height:40px;text-align:center}#rev_slider_2_1_wrapper .hesperiden.tparrows.tp-leftarrow:before{content:'\e82c'; margin-left:-3px}#rev_slider_2_1_wrapper .hesperiden.tparrows.tp-rightarrow:before{content:'\e82d'; margin-right:-3px}#rev_slider_2_1_wrapper .uranus .tp-bullet{border-radius:50%; box-shadow:0 0 0 2px rgba(255,255,255,0); -webkit-transition:box-shadow 0.3s ease; transition:box-shadow 0.3s ease; background:transparent; width:15px; height:15px}#rev_slider_2_1_wrapper .uranus .tp-bullet.selected,#rev_slider_2_1_wrapper .uranus .tp-bullet.rs-touchhover{box-shadow:0 0 0 2px rgba(255,255,255,1); border:none; border-radius:50%; background:transparent}#rev_slider_2_1_wrapper .uranus .tp-bullet-inner{-webkit-transition:background-color 0.3s ease,-webkit-transform 0.3s ease; transition:background-color 0.3s ease,transform 0.3s ease; top:0; left:0; width:100%; height:100%; outline:none; border-radius:50%; background-color:rgba(255,255,255,0); background-color:rgba(255,255,255,0.3); text-indent:-999em; cursor:pointer; position:absolute}#rev_slider_2_1_wrapper .uranus .tp-bullet.selected .tp-bullet-inner,#rev_slider_2_1_wrapper .uranus .tp-bullet.rs-touchhover .tp-bullet-inner{transform:scale(0.4); -webkit-transform:scale(0.4); background-color:rgba(255,255,255,1)}</style>