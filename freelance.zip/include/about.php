<!-- section one -->
			<section class="mt-5 pg whyUs"  data-aos="fade-up">
				<div class="container-fluid section-one">
					<div class="row">
						<div class="col-1 d-none d-xl-block">
							<div class="about-heading">ABOUT<span>US</span></div>
						</div>
						<div class="col-xl-5 col-lg-6 mt-5">
							<img width="100%" src="assets/section-one.png">
						</div>
						<div class="col-xl-5 col-lg-6 mt-5">
							<div class="section-one-sec">
							<h3>Houston Web Development</h3>
							<div class="hr"></div>
							<p><b>Offering the services of the best web development company | Houston, Texas</b></p>
							<p class="color-lightgray section-one-p">
								The best way to make a name for your business in the market is to perform exceptionally well. But to do that, your presence as a stellar developer must be made on the digital platform. How would clients know about you if you do not give them a platform to evaluate your company?
								<br>
								That’s where we come in. In this digital age, we can help you build an amazing website that will catch the attention of clients everywhere. A well-designed and optimized website will make sure you top the lists of search engines everywhere! A client only has to search for a service provider and a well-optimized website will make sure your company’s name comes on top. Operating throughout Houston, SEO services of the highest order can be found with CustomWebnLogoDesigns.
							</p>
							</div>
							<div class="row section-one-box">
								
								<div class="col-xl-4 col-lg-6 col-sm-4">
								<center>
								<div class="section-one-box1">
									<img class="box-icon" src="assets/box-icon1.png">
								</div>
								<p>Attractive Design<img class="section-one-hr" src="assets/hr.png"></p>
								</center>
								</div>

								<div class="col-xl-4 col-lg-6 col-sm-4">
								<center>
								<div class="section-one-box2">
									<img class="box-icon" src="assets/box-icon2.png">
								</div>
								<p>Immaculate Performance<img class="section-one-hr" src="assets/hr.png"></p>
								</center>
								</div>

								<div class="col-xl-4 col-lg-12 col-sm-4">
								<center>
								<div class="section-one-box3 text-center">
									<img class="box-icon" src="assets/box-icon3.png">
								</div>
								<p>Engaging Content<img class="section-one-hr" src="assets/hr.png"></p>
								
								</center>
								</div>
							</div>
						</div>
						<div class="col-1 d-none d-xl-block">
							<img width="90%" src="assets/section-one-icon.png">
						</div>
						<div class="col-12 text-center section-one-bottom">
							CUSTOM WEB & LOGO
						</div>
					</div>
				</div>
			</section>
			<!-- section one end-->