<div class="col-lg-6 col-12">
                                <div class="card" data-aos="fade-up">
                                    <div class="card-header">
                                        <h2>70% DISCOUNT</h2>
                                    </div>
                                    <div class="card-body">
                                        <h3>
                                            Let’s start your project, 
                                            <strong>Drop us your details!</strong>
                                        </h3>
                                        <div data-form-type="signup_form">
    <form class="leadForm" method="post" enctype="multipart/form-data" action="javascript:void(0)">
        <div class="form-group">
            <label for="name" class="d-none">Name</label>
            <input type="text" name="name" data-validation="required"  class="form-control btn-rounded" id="name" placeholder="Your Name">
        </div>
        <div class="form-group">
            <label for="email" class="d-none">email</label>
            <input type="email" name="email" data-validation="required" class="form-control btn-rounded" id="email" placeholder="Email Address">
        </div>
        <div class="form-group">
            <label for="number" class="d-none">phone</label>
            <input type="tel" name="phone" data-validation="required" class="form-control btn-rounded" id="phone" placeholder="Phone Number">
        </div>
        <div id="formResult"></div>
        <div class="form-group">
            <button value="1" name="signupForm" type="submit" class="btn btn-rounded btn-yellow btn-block">Submit your Request</button>
        </div>
    </form>
</div>                                        <p>
                                            *Our Consultant will call you to confirm your package
                                        </p>
                                    </div>
                                </div>
                            </div>