<!DOCTYPE html>
<html lang="en">
    <head>
        <title>E-Commerce - Custom Web N Logo Design</title>
        <?php
            require_once("include/head.php");
        ?>
        <link rel="stylesheet" href="css/inner-custom.css">
    </head>
    <body>
        <?php
            require_once("include/nav.php");
        ?>
                <main>
            <section class="banner">
                <div class="banner-img">
                    <img src="inner/img/banner_video.jpg" alt="banner">
                </div>
                <div class="banner-content no-bg">
                    <div class="container">
                        <div class="row">
                            <div class="col-lg-6 col-12">
                                <div class="row">
                                    <div class="col">
                                        <i class="sprite_1 sprite-Lban1" data-aos="fade-up"></i>
                                    </div>
                                    <div class="col" data-aos="fade-up">
                                        <i class="sprite_1 sprite-Lban2"></i>
                                    </div>
                                    <div class="col" data-aos="fade-up">
                                        <i class="sprite_1 sprite-Lban3"></i>
                                    </div>
                                    <div class="col-12">
                                        <div class="service-desc" data-aos="fade-right">
                                            <h2>
                                                SPARK UP YOUR BRAND 
                                                <span>WITH PROFESSIONAL ANIMATIONS</span>
                                            </h2>
                                            <button class="btn btn-rounded btn-white-outline">Upto 70% off on all packages!</button>
                                            <div class="col-12 col-md-6 p-0">
                                                <a href="javascript:void(0);" class="btn btn-rounded btn-black popupBox d-lg-none d-block" data-toggle="modal" data-target="getQuote">lets get started</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <?php
                                require_once("include/inner-top-form.php");
                            ?>
                        </div>
                    </div>
                </div>
            </section>
            <div id="exTab1">	
                <div class="middle-nav">
                    <ul class="nav nav-pills">
                        <li class="active">
                            <a  href="#1a" class="active" data-toggle="tab">E-Commerce Animation</a>
                        </li>
                        <li>
                            <a href="#2a" data-toggle="tab">E-Commerce package</a>
                        </li>
                        <li>
                            <a href="#3a" data-toggle="tab">E-Commerce process</a>
                        </li>
                        <li>
                            <a href="#4a" data-toggle="tab">faqs</a>
                        </li>
                    </ul>
                </div>
                <div class="tab-content clearfix">
                                <div class="tab-pane active" id="1a">
                                    <?php
                               require_once("include/about.php");
                            ?>
                                    <section class="pg glimpse" data-aos="fade-down">
                                        <div class="container">
                                            <div class="row">
                                                <div class="col-12 text-center">
                                                    <h2 class="title">A Glimpse Of Our Works</h2>
                                                    <p>What we do is simply far superior than others</p>
                                                    <ul class="tabs d-none" id="glimpse">
                                                        <li class="tab-link current" data-tab="tab-1">All</li>
                                                        <li class="tab-link" data-tab="tab-2">2D Animations</li>
                                                        <li class="tab-link" data-tab="tab-3">3D Animations</li>
                                                        <li class="tab-link" data-tab="tab-4">Whiteboard Animations </li>
                                                        <li class="tab-link" data-tab="tab-5">Typographic</li>
                                                        <li class="tab-link" data-tab="tab-6">Explainer E-Commerce </li>
                                                    </ul>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="container-fluid">
                                            <div class="row">
                                                <div class="tab-content current" id="tab-1">
                                                    <div class="workGal">
                                                        <ul class="workList">
                                                            <li><a href="assets/ecommerce/1.jpg"><i class="fa fa-search"></i></a><img src="assets/ecommerce/1.jpg" alt=""></li>
                                                            <li><a href="assets/ecommerce/2.jpg" class="video"><i class="fa fa-search"></i></a><img src="assets/ecommerce/2.jpg" alt=""></li>
                                                            <li><a href="assets/ecommerce/3.jpg"><i class="fa fa-search"></i></a><img src="assets/ecommerce/3.jpg" alt=""></li>
                                                            <li><a href="assets/ecommerce/4.jpg" class="video"><i class="fa fa-search"></i></a><img src="assets/ecommerce/4.jpg" alt=""></li>
                                                            <li><a href="assets/ecommerce/5.jpg"><i class="fa fa-search"></i></a><img src="assets/ecommerce/5.jpg" alt=""></li>
                                                            <li><a href="assets/ecommerce/6.png"><i class="fa fa-search"></i></a><img src="assets/ecommerce/6.png" alt=""></li>
                                                            <li><a href="assets/ecommerce/7.jpg" class="video"><i class="fa fa-search"></i></a><img src="assets/ecommerce/7.jpg" alt=""></li>
                                                            <li><a href="assets/ecommerce/8.jpg"><i class="fa fa-search"></i></a><img src="assets/ecommerce/8.jpg" alt=""></li>
                                                             <li><a href="assets/ecommerce/9.jpg"><i class="fa fa-search"></i></a><img src="assets/ecommerce/9.jpg" alt=""></li>
                                                              <li><a href="assets/ecommerce/10.jpg"><i class="fa fa-search"></i></a><img src="assets/ecommerce/10.jpg" alt=""></li>
                                                           
                                                        </ul>
                                                    </div>
                                                </div>
                                                <div class="tab-content" id="tab-2">
                                                    <div class="workGal">
                                                        <ul class="workList">
                                                            <li><img src="inner/img/vd1.jpg" alt=""></li>
                                                            <li><img src="inner/img/vd2.jpg" alt=""></li>
                                                            <li><img src="inner/img/vd8.jpg" alt=""></li>
                                                            <li><img src="inner/img/vd3.jpg" alt=""></li>
                                                            <li><img src="inner/img/vd4.jpg" alt=""></li>
                                                            <li><img src="inner/img/vd5.jpg" alt=""></li>
                                                            <li><img src="inner/img/vd6.jpg" alt=""></li>
                                                            <li><img src="inner/img/vd7.jpg" alt=""></li>
                                                            <li><img src="inner/img/vd9.jpg" alt=""></li>
                                                            <li><img src="inner/img/vd10.jpg" alt=""></li>
                                                        </ul>
                                                    </div>
                                                </div>  
                                                <div class="tab-content" id="tab-3">
                                                    <div class="workGal">
                                                        <ul class="workList">
                                                            <li><img src="inner/img/vd1.jpg" alt=""></li>
                                                            <li><img src="inner/img/vd2.jpg" alt=""></li>
                                                            <li><img src="inner/img/vd3.jpg" alt=""></li>
                                                            <li><img src="inner/img/vd4.jpg" alt=""></li>
                                                            <li><img src="inner/img/vd5.jpg" alt=""></li>
                                                            <li><img src="inner/img/vd6.jpg" alt=""></li>
                                                            <li><img src="inner/img/vd7.jpg" alt=""></li>
                                                            <li><img src="inner/img/vd8.jpg" alt=""></li>
                                                            <li><img src="inner/img/vd9.jpg" alt=""></li>
                                                            <li><img src="inner/img/vd10.jpg" alt=""></li>
                                                        </ul>
                                                    </div>
                                                </div>
                                                <div class="tab-content" id="tab-4">
                                                    <div class="workGal">
                                                        <ul class="workList">
                                                            <li><img src="inner/img/vd1.jpg" alt=""></li>
                                                            <li><img src="inner/img/vd2.jpg" alt=""></li>
                                                            <li><img src="inner/img/vd8.jpg" alt=""></li>
                                                            <li><img src="inner/img/vd3.jpg" alt=""></li>
                                                            <li><img src="inner/img/vd4.jpg" alt=""></li>
                                                            <li><img src="inner/img/vd5.jpg" alt=""></li>
                                                            <li><img src="inner/img/vd6.jpg" alt=""></li>
                                                            <li><img src="inner/img/vd7.jpg" alt=""></li>
                                                            <li><img src="inner/img/vd9.jpg" alt=""></li>
                                                            <li><img src="inner/img/vd10.jpg" alt=""></li>
                                                        </ul>
                                                    </div>
                                                </div>  
                                                <div class="tab-content" id="tab-5">
                                                    <div class="workGal">
                                                        <ul class="workList">
                                                            <li><img src="inner/img/vd1.jpg" alt=""></li>
                                                            <li><img src="inner/img/vd2.jpg" alt=""></li>
                                                            <li><img src="inner/img/vd3.jpg" alt=""></li>
                                                            <li><img src="inner/img/vd4.jpg" alt=""></li>
                                                            <li><img src="inner/img/vd5.jpg" alt=""></li>
                                                            <li><img src="inner/img/vd6.jpg" alt=""></li>
                                                            <li><img src="inner/img/vd7.jpg" alt=""></li>
                                                            <li><img src="inner/img/vd8.jpg" alt=""></li>
                                                            <li><img src="inner/img/vd9.jpg" alt=""></li>
                                                            <li><img src="inner/img/vd10.jpg" alt=""></li>
                                                        </ul>
                                                    </div>
                                                </div>
                                                <div class="tab-content" id="tab-6">
                                                    <div class="workGal">
                                                        <ul class="workList">
                                                            <li><img src="inner/img/vd1.jpg" alt=""></li>
                                                            <li><img src="inner/img/vd2.jpg" alt=""></li>
                                                            <li><img src="inner/img/vd8.jpg" alt=""></li>
                                                            <li><img src="inner/img/vd3.jpg" alt=""></li>
                                                            <li><img src="inner/img/vd4.jpg" alt=""></li>
                                                            <li><img src="inner/img/vd5.jpg" alt=""></li>
                                                            <li><img src="inner/img/vd6.jpg" alt=""></li>
                                                            <li><img src="inner/img/vd7.jpg" alt=""></li>
                                                            <li><img src="inner/img/vd9.jpg" alt=""></li>
                                                            <li><img src="inner/img/vd10.jpg" alt=""></li>
                                                        </ul>
                                                    </div>
                                                </div>                                       
                                            </div>
                                        </div>
                                    </section>
                                    <section class="pg" data-aos="fade-up">
                                        <div class="container">
                                            <div class="row">
                                                <div class="col-12">
                                                    <ul class="list-center">
                                                        <li><a href="#" class="btn btn-rounded btn-black btn-block btn-lg popupBox" data-toggle="modal" data-target="getQuote">lets get started</a></li>
                                                        <li><a href="#" class="btn btn-rounded btn-white-outline active chatt btn-lg">chat now</a></li>
                                                    </ul>
                                                </div>
                                            </div>
                                        </div>
                                    </section>
                                    <section class="pg" data-aos="fade-down">
                                        <div class="simplerSol">
                                            <div class="container">
                                                <div class="row">
                                                    <div class="col-md-12">
                                                        <div class="text-center">
                                                            <h2 class="title">Higher Quality. Better Branding. Faster Results.</h2>
                                                            <p>
                                                           The Custom Web N Logo Design is skilled in various styles and techniques of animation so that you get exactly what you're looking for.
                                                            </p>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div id="serviceSlider">
                                                    <div class="ss-slider">
                                                        <div class="row">
                                                            <div class="col-md-6">
                                                                <h3>3D Animations</h3>
                                                                <p>
                                                                    For a more detailed and high quality approach, The Custom Web N Logo Design recommend 3D
                                                                    animtion E-Commerce. You can add detail and depth to little elements of your
                                                                    brand like logo, graphics, 3D character or promotional E-Commerce. These
                                                                    little details end up being far more reawarding for your brand in the long
                                                                    run. Our 3D animations are award-winning and give spark to your brand
                                                                    with maximum viewer engagement.
                                                                </p>
                                                                <ul class="arrow-list">
                                                                    <li>Comprehensive & Detailed</li>
                                                                    <li>Wider Audience</li>
                                                                    <li>Better Branding</li>
                                                                    <li>100% Satisfaction</li>
                                                                </ul>
                                                            </div>
                                                            <div class="col-md-6">
                                                                <img src="inner/img/3dA.jpg" alt="ss">
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="ss-slider">
                                                        <div class="row">
                                                            <div class="col-md-6">
                                                                <h3>2D Animations</h3>
                                                                <p>
                                                                    2D animation is the perfect solution for small and medium-scale businesses who are looking for fast and cheap fix to their branding strategies. We make 2D animations using the latest software while  keeping your budget and timelines in mind. We make 2D animation easier and accessible to all so they can maximize their digital presence with modern solutions of The Custom Web N Logo Design.
                                                                </p>
                                                                <ul class="arrow-list">
                                                                    <li>Character Animation</li>
                                                                    <li>Graphics Animation</li>
                                                                    <li>Fully Customized</li>
                                                                    <li>100% Guaranteed Satisfaction</li>
                                                                </ul>
                                                            </div>
                                                            <div class="col-md-6">
                                                                <img src="inner/img/2dA.jpg" alt="ss">
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </section>
                                </div>
                                <div class="tab-pane" id="2a">
                                    <div class="pg secretDelievery">
                                        <div class="container">
                                            <div class="row">
                                                <div class="col-12">
                                                    <h2 class="title">Looking for a creative E-Commerce </h2>
                                                    <p>That converses your brand personality? We create custom E-Commerce animations that raise appeal and brand.  </p>
                                                    <ul class="creativity">
                                                        <li>
                                                            <div class="quote" style="background-image: url('inner/img/revision.png');">
                                                                <i>
                                                                    <img src="inner/img/revision.png" alt="quote">
                                                                </i>
                                                                <p>Unlimited Revisions</p>
                                                            </div>
                                                        </li>
                                                        <li>
                                                            <div class="quote" style="background-image: url('inner/img/ownership.png');">
                                                                <i>
                                                                    <img src="inner/img/ownership.png" alt="quote">
                                                                </i>
                                                                <p>100% Ownership Rights</p>
                                                            </div>
                                                        </li>
                                                        <li>
                                                            <div class="quote" style="background-image: url('inner/img/moneyBack.png');">
                                                                <i>
                                                                    <img src="inner/img/moneyBack.png" alt="quote">
                                                                </i>
                                                                <p>100% Money Back Guarantee</p>
                                                            </div>
                                                        </li>
                                                    </ul>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <!--section package -->
            <section class="package">
                <div class="text-center">
                    <h2>Reasonable <b>Design Packages</b></h2>
                        <p>Custom Web N Logo Design has reasonably tailored packages suitable for your requirments and budget so we have something for everyone.</p>
                        <?php
                            require_once("package/e-commerce-package.php");
                        ?>
                </div>
            </section>
            <!--section package end -->
            <br><br>
            <?php
                require_once("include/key.php");
            ?>
                                </div>
                                <div class="tab-pane" id="3a">
                                    <div class="pg secretDelievery" data-aos="fade-down">
                                        <div class="container">
                                            <div class="row">
                                                <div class="col-md-12 text-center">
                                                    <h2 class="title">Our Secret To Always Deliver Above Average</h2>
                                                    <p>Lies in our flawless and efficient process, delivering 110% satisfaction!</p>
                                                    <ul class="list-center">
                                                        <li>
                                                            <i class="sprite_1 sprite-sQ"></i>
                                                            <h4>Fill out our simple questionnaire</h4>
                                                            <p>This helps our experts to analyze the requirements, and take your project in right direction.</p>
                                                        </li>
                                                        <li>
                                                            <i class="sprite_1 sprite-appD"></i>
                                                            <h4>Script and  <br>Storyboard</h4>
                                                            <p>Our talented writers come up with a perfectly tailored script for you and our illustrators deliver the storyboard within days.</p>
                                                        </li>
                                                        <li>
                                                            <i class="sprite_1 sprite-vV"></i>
                                                            <h4>E-Commerce  <br>Voiceover</h4>
                                                            <p>A good audio is necessary to preserve the quality of a E-Commerce. We deliver you relevant audio files for your animation.</p>
                                                        </li>
                                                        <li>
                                                            <i class="sprite_1 sprite-fD"></i>
                                                            <h4>Animation<br>Designs</h4>
                                                            <p>
                                                                As soon as you approve the audio & the toryboarding, our animatiors get started on your fully customized animation E-Commerce.
                                                            </p>
                                                        </li>
                                                        <li>
                                                            <i class="sprite_1 sprite-pD"></i>
                                                            <h4>Final <br>Delivery</h4>
                                                            <p>
                                                                After making sure everything is pixel perfect with multiple Q/A sessions. We deliver final files to our clients in their preferred formats.
                                                            </p>
                                                        </li>
                                                    </ul>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="tab-pane" id="4a">
                                    <div class="pg secretDelievery" data-aos="fade-up">
                                        <div class="container">
                                            <div class="row">
                                                <div class="col-md-12 text-center">
                                                    <h2 class="title">FAQS</h2>
                                                    <p>
                                                        For All Your General Queries, Go Through Our Detailed FAQS.
                                                    </p>
                                                    <ul class="arrow-list">
                                                        <li>
                                                            <h4>Why do I need animation services?</h4>
                                                            <p>An animation E-Commerce, graphic or character can be used in various marketing and branding ways. To learn more about animation services and its uses, go through our services page for detailed benefits and uses.</p>
                                                        </li>
                                                        <li>
                                                            <h4>What is the total turnaround time of an animated E-Commerce?</h4>
                                                            <p>Depends on the frames per second and the lenght of your total project. Usually we can say that it takes our experts around 4 to 5 weeks.</p>
                                                        </li>
                                                        <li>
                                                            <h4>Is there a limit on E-Commerce duration?</h4>
                                                            <p>No, you can specify the details and requirements for your project so our experts can kepp it to a suitable length.</p>
                                                        </li>
                                                        <li>
                                                            <h4>What format will I recieve my E-Commerce animation?</h4>
                                                            <p>Anyway you prefer it. We reccomend AVI for greater quality, DVDs for commercial use and MP4 for website use.</p>
                                                        </li>
                                                        <li>
                                                            <h4>How do I get started?</h4>
                                                            <p>Fill our contact form, chat live or call our consultants.</p>
                                                        </li>
                                                        
                                                    </ul>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
            </div>
              <?php
            require_once("include/inner-counter.php");
            require_once("include/contact.php");
            require_once("include/client.php");
            ?>
        </main>
        <!--subscribe-->
<form method="post" id="sub">
            <section class="subscribe container-fluid">
                <div class="container">
                    <div class="row">
                        <div class="col-xl-5 text-center">
                            <h3>Looking for the finest web development company, Houston, Texas? Here we are.</h3>
                        </div>
                        <div class="col-xl-7">
                            <div class="input-container">
                                <i class="fa fa-envelope-o sub-icon" aria-hidden="true"></i>
                                <input name="email" class="input-field" type="email" placeholder="Enter Email Address..." required>
                                <div class="sub-btn-back">
                                <input  class="sub-btn" type="submit" name="" value="LET'S START"></div>
                               
                            </div>

                        </div>
                    </div>
                </div>
            </section>

             </form>
            <!--subscribe end-->
        <?php
            require_once("include/footer.php");
            require_once("include/script.php");
?>
</html>
    
    <script>
        $(window).bind('load resize', function () {
                    // $('#parent').append('<div>hello</div>');    
                    var viewWidth = $(window).width();
                    if(viewWidth > 767){
                        $('#serviceSlider').on('afterChange', function(slick, currentSlide){
                        var get_index = currentSlide.currentSlide;
                        switch(get_index){
                            case 0:
                                $(this).find('img').after('<img src="inner/img/ED-bg.png" class="bg-img">');
                                break;
                            case 1:
                                $(this).find('img').after('<img src="inner/img/TA-bg.png" class="bg-img">');
                                break;
                            case 2:
                                $(this).find('img').after('<img src="inner/img/WBA-bg.png" class="bg-img">');
                                break;
                            case 3:
                                $(this).find('img').after('<img src="inner/img/3dA-bg.png" class="bg-img">');
                                break;
                            case 4:
                                $(this).find('img').after('<img src="inner/img/2dA-bg.png" class="bg-img">');
                                break;
                        }
                        });
                        $('#serviceSlider').on('beforeChange', function (slick, currentSlide, nextSlide) {
                            var get_index = currentSlide.currentSlide;
                            switch(get_index){
                                case 0:
                                    $(this).find('img.bg-img').remove();
                                    break;
                                case 1:
                                    $(this).find('img.bg-img').remove();
                                    break;
                                case 2:
                                    $(this).find('img.bg-img').remove();
                                    break;
                                case 3:
                                    $(this).find('img.bg-img').remove();
                                    break;
                                case 4:
                                    $(this).find('img.bg-img').remove();
                                    break;
                            }                          
                        });
                        $('#serviceSlider').find('img').after('<img src="inner/img/ED-bg.png" class="bg-img">');
                    }
                })
    </script>