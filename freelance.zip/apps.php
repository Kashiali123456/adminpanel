<!DOCTYPE html>
<html lang="en">
    <head>
        <title>App - Custom Web N Logo Design</title>
        <?php
            require_once("include/head.php");
        ?>
        <link rel="stylesheet" href="css/inner-custom.css">
    </head>
    <body>
       <?php
            require_once("include/nav.php");
        ?>
                <main>
            <section class="banner">
                <div class="banner-img">
                    <img src="inner/img/banner-app.jpg" alt="banner">
                </div>
                <div class="banner-content no-bg">
                    <div class="container">
                        <div class="row">
                            <div class="col-lg-6 col-12">
                                <div class="row">
                                    <div class="col" data-aos="fade-up">
                                        <div class="service IS">
                                            <i class="sprite sprite-ban1"></i>
                                            <p>Industry-specific</p>
                                        </div>
                                    </div>
                                    <div class="col" data-aos="fade-up">
                                        <div class="service resp">
                                            <i class="sprite sprite-ban2"></i>
                                            <p>Responsive</p>
                                        </div>
                                    </div>
                                    <div class="col" data-aos="fade-up">
                                        <div class="service uiux">
                                            <i class="sprite sprite-ban3"></i>
                                            <p>UX/UI Friendly</p>
                                        </div>
                                    </div>
                                    <div class="col-12">
                                        <div class="service-desc" data-aos="fade-left">
                                            <h2>
                                                Make Your Interactive Platform on the Digital Frontier!  
                                                <span>With the help of the finest mobile app development company | Houston.</span>
                                            </h2>
                                            <button class="btn btn-rounded btn-white-outline">Check out our Packages!</button>
                                            <div class="col-12 col-md-6 p-0">
                                                <a href="javascript:void(0);" class="btn btn-rounded btn-black popupBox d-lg-none d-block" data-toggle="modal" data-target="getQuote">lets get started</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <?php
                                require_once("include/inner-top-form.php");
                            ?>
                        </div>
                    </div>
                </div>
            </section>

            <div id="exTab1">	
                <div class="middle-nav">
                    <ul class="nav nav-pills">
                        <li class="active">
                            <a  href="#1a" class="active" data-toggle="tab">app design</a>
                        </li>
                        <li>
                            <a href="#2a" data-toggle="tab">app process</a>
                        </li>
                        <li>
                            <a href="#3a" data-toggle="tab">faqs</a>
                        </li>
                    </ul>
                </div>
                <div class="tab-content clearfix">
                    <div class="tab-pane active" id="1a">
                           <!-- section one -->
            <section class="mt-5 pg whyUs"  data-aos="fade-up">
                <div class="container-fluid section-one">
                    <div class="row">
                        <div class="col-1 d-none d-xl-block">
                            <div class="about-heading">ABOUT<span>US</span></div>
                        </div>
                        <div class="col-xl-5 col-lg-6 mt-5">
                            <img width="100%" src="assets/section-one.png">
                        </div>
                        <div class="col-xl-5 col-lg-6 mt-5">
                            <div class="section-one-sec">
                            <h3>Mobile App Development | Houston</h3>
                            <div class="hr"></div>
                            <p><b>Turn your Business Ideas into Creative and Interactive Mobile Apps. </b></p>
                            <p class="color-lightgray section-one-p">
                                With advancements in technology, electronic devices are widely available everywhere throughout the world. On average, People spend 3-4 hours of their day using their smartphones. This has become the norm of our lives. This is precisely why, entire businesses, retail stores, studies, all of it is being done through the use of mobile applications on smartphones. It is now a necessity that B2C companies make great use of mobile applications to increase their customer base and induce growth in their profits and revenue. If they fail to do so, they risk falling behind their competition.
                                CustomWebnLogoDesign is the one company you need in your corner to make Custom Web N Logo Design image strong. To that end, you’d need to develop websites, mobile apps, and invest heavily in social media marketing/ digital marketing. Many promising entrepreneurs launch their start ups on mobile applications since they are easy to use for everyone. CustomWebnLogoDesign can make for your company a clean and user-friendly efficient platform to build your digital fortress. 
                                <br>
                               Great User-Interface, Functionable Design, Aesthetically Pleasing
                            </p>
                            </div>
                            <div class="row section-one-box">
                                
                                <div class="col-xl-4 col-lg-6 col-sm-4">
                                <center>
                                <div class="section-one-box1">
                                    <img class="box-icon" src="assets/box-icon1.png">
                                </div>
                                <p>Attractive Design<img class="section-one-hr" src="assets/hr.png"></p>
                                </center>
                                </div>

                                <div class="col-xl-4 col-lg-6 col-sm-4">
                                <center>
                                <div class="section-one-box2">
                                    <img class="box-icon" src="assets/box-icon2.png">
                                </div>
                                <p>Immaculate Performance<img class="section-one-hr" src="assets/hr.png"></p>
                                </center>
                                </div>

                                <div class="col-xl-4 col-lg-12 col-sm-4">
                                <center>
                                <div class="section-one-box3 text-center">
                                    <img class="box-icon" src="assets/box-icon3.png">
                                </div>
                                <p>Engaging Content<img class="section-one-hr" src="assets/hr.png"></p>
                                
                                </center>
                                </div>
                            </div>
                        </div>
                        <div class="col-1 d-none d-xl-block">
                            <img width="90%" src="assets/section-one-icon.png">
                        </div>
                        <div class="col-12 text-center section-one-bottom">
                            CUSTOM WEB & LOGO
                        </div>
                    </div>
                </div>
            </section>
            <!-- section one end-->
                            <section class="pg glimpse" data-aos="fade-down">
                                <div class="container">
                                    <div class="row">
                                        <div class="col-12 text-center">
                                            <h2 class="title">SHOWCASING</h2>
                                            <p>The apps developed by CustomWebnLogoDesign</p>
                                            <ul class="tabs d-none" id="glimpse">
                                                <li class="tab-link current" data-tab="tab-1">All</li>
                                                <li class="tab-link" data-tab="tab-2">Android</li>
                                                <li class="tab-link" data-tab="tab-3">iOS</li>
                                                <li class="tab-link" data-tab="tab-4">Native React</li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                                <div class="container-fluid">
                                    <div class="row">
                                        <div class="tab-content current" id="tab-1">
                                            <div class="workGal">
                                            <ul class="workList">
                                                <li><a href="inner/img/w1.jpg" class="image-link"><i class="fa fa-search"></i></a><img src="inner/img/w1.jpg" alt=""></li>
                                                <li><a href="inner/img/w2.jpg" class="image-link"><i class="fa fa-search"></i></a><img src="inner/img/w2.jpg" alt=""></li>
                                                <li><a href="inner/img/w3.jpg" class="image-link"><i class="fa fa-search"></i></a><img src="inner/img/w3.jpg" alt=""></li>
                                                <li><a href="inner/img/w4.jpg" class="image-link"><i class="fa fa-search"></i></a><img src="inner/img/w4.jpg" alt=""></li>
                                                <li><a href="inner/img/w5.jpg" class="image-link"><i class="fa fa-search"></i></a><img src="inner/img/w5.jpg" alt=""></li>
                                                <li><a href="inner/img/w6.jpg" class="image-link"><i class="fa fa-search"></i></a><img src="inner/img/w6.jpg" alt=""></li>
                                                <li><a href="inner/img/w7.jpg" class="image-link"><i class="fa fa-search"></i></a><img src="inner/img/w7.jpg" alt=""></li>
                                                <li><a href="img/w8.jpg" class="image-link"><i class="fa fa-search"></i></a><img src="inner/img/w8.jpg" alt=""></li>
                                                <li><a href="inner/img/w9.jpg" class="image-link"><i class="fa fa-search"></i></a><img src="inner/img/w9.jpg" alt=""></li>
                                                <li><a href="inner/img/w10.jpg" class="image-link"><i class="fa fa-search"></i></a><img src="inner/img/w10.jpg" alt=""></li>
                                            </ul>
                                            </div>
                                        </div>
                                        <div class="tab-content" id="tab-2">
                                            <div class="workGal">
                                                <ul class="workList">
                                                    <li><img src="inner/img/w6.jpg" alt=""></li>
                                                    <li><img src="inner/img/w7.jpg" alt=""></li>
                                                    <li><img src="inner/img/w8.jpg" alt=""></li>
                                                    <li><img src="inner/img/w9.jpg" alt=""></li>
                                                    <li><img src="inner/img/w10.jpg" alt=""></li>
                                                    <li><img src="inner/img/w1.jpg" alt=""></li>
                                                    <li><img src="inner/img/w2.jpg" alt=""></li>
                                                    <li><img src="inner/img/w3.jpg" alt=""></li>
                                                    <li><img src="inner/img/w4.jpg" alt=""></li>
                                                    <li><img src="inner/img/w5.jpg" alt=""></li>
                                                </ul>
                                            </div>
                                        </div>
                                        <div class="tab-content" id="tab-3">
                                            <div class="workGal">
                                                <ul class="workList">
                                                    <li><img src="inner/img/w4.jpg" alt=""></li>
                                                    <li><img src="inner/img/w5.jpg" alt=""></li>
                                                    <li><img src="inner/img/w6.jpg" alt=""></li>
                                                    <li><img src="inner/img/w1.jpg" alt=""></li>
                                                    <li><img src="inner/img/w2.jpg" alt=""></li>
                                                    <li><img src="inner/img/w3.jpg" alt=""></li>
                                                    <li><img src="inner/img/w7.jpg" alt=""></li>
                                                    <li><img src="inner/img/w8.jpg" alt=""></li>
                                                    <li><img src="inner/img/w9.jpg" alt=""></li>
                                                    <li><img src="inner/img/w10.jpg" alt=""></li>
                                                </ul>
                                            </div>
                                        </div>
                                        <div class="tab-content" id="tab-4">
                                            <div class="workGal">
                                                <ul class="workList">
                                                    <li><img src="inner/img/w1.jpg" alt=""></li>
                                                    <li><img src="inner/img/w2.jpg" alt=""></li>
                                                    <li><img src="inner/img/w3.jpg" alt=""></li>
                                                    <li><img src="inner/img/w4.jpg" alt=""></li>
                                                    <li><img src="inner/img/w5.jpg" alt=""></li>
                                                    <li><img src="inner/img/w6.jpg" alt=""></li>
                                                    <li><img src="inner/img/w7.jpg" alt=""></li>
                                                    <li><img src="inner/img/w8.jpg" alt=""></li>
                                                    <li><img src="inner/img/w9.jpg" alt=""></li>
                                                    <li><img src="inner/img/w10.jpg" alt=""></li>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </section>
                            <section class="pg" data-aos="fade-up">
                                <div class="container">
                                    <div class="row">
                                        <div class="col-12">
                                            <ul class="list-center">
                                                <li><a href="#" class="btn btn-rounded btn-black btn-block btn-lg popupBox" data-toggle="modal" data-target="getQuote">Learn More</a></li>
                                                <li><a href="#" class="btn btn-rounded btn-white-outline active chatt btn-lg">Contact us Now</a></li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </section>
                            <section class="pg" data-aos="fade-down">
                                <div class="simplerSol">
                                    <div class="container">
                                        <div class="row">
                                            <div class="col-md-12">
                                                <div class="text-center">
                                                    <h2 class="title">Mobile App Development | Houston</h2>
                                                    <p>Simple and Elegant Digital Solutions. All types of app development available.</p>
                                                </div>
                                            </div>
                                        </div>
                                        <div id="serviceSlider">
                                            <div class="ss-slider">
                                                <div class="row">
                                                    <div class="col-md-6">
                                                        <h3>ANDROID APPLICATIONS</h3>
                                                        <p>
                                                           Android is the most prolific platform for mobile app development. Easy to use for businesses and customers, Android applications have a wide reach that can help brands connect with everyone on an international level. CustomWebnLogoDesign can transform your business idea into a cutting-edge, innovative, and responsive smartphone application that increases exposure and generates profit and revenue. Active on all smart devices, we can make an app for all types of businesses. 
                                                        </p>
                                                        <ul class="arrow-list">
                                                            <li>Advanced API Integration Between Apps.</li>
                                                            <li>A Common Platform for wearable tech using the Internet of Things.</li>
                                                            <li>The Whole Android Digital Solutions Package.</li>
                                                        </ul>
                                                    </div>
                                                    <div class="col-md-6">
                                                        <img src="inner/img/ss.jpg" alt="ss">
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="ss-slider">
                                                <div class="row">
                                                    <div class="col-md-6">
                                                        <h3>IOS APPLICATIONS</h3>
                                                        <p>
                                                        The iOS app developers of CustomWebnLogoDesign utilizes advanced tech stack techniques like Swift, Apple Xcode, and iOS SDK to develop smartphone applications on the most popular operating software out there. We can take your business to the next level so that your company shoots for the stars. iOS Applications working on all Apple Devices, from Apple Watches, iPads, and even iPhones, are all effectively developed and placed on the App Store to increase your revenue.
                                                        </p>
                                                        <ul class="arrow-list">
                                                            <li>API Integration between all iOS Applications.</li>
                                                            <li>Experienced team of iOS Developers.</li>
                                                            <li>Incredible User Friendly Interface.</li>
                                                        </ul>
                                                    </div>
                                                    <div class="col-md-6">
                                                        <img src="inner/img/IOS.png" alt="ss">
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="ss-slider">
                                                <div class="row">
                                                    <div class="col-md-6">
                                                        <h3>NATIVE REACT APPS</h3>
                                                        <p>
                                                            It is not wise to only target a single demographic when it comes to app development. To increase your reach, your app must be operable on all platforms available like Android and iOS. With a common code base across all platforms, CustomWebnLogoDesign uses Native React to make a quick and responsive application that grabs hold of both Android and iOS markets. Our phenomenal team of app developers are the best in the business. From palm to the wrist, our custom smartphone apps work efficiently anytime and anywhere.
                                                        </p>
                                                        <ul class="arrow-list">
                                                            <li>Best for E-Commerce Stores.</li>
                                                            <li>Safe and Secure; A Digital Fort Knox.</li>
                                                            <li>Super User Experience Design.</li>
                                                        </ul>
                                                    </div>
                                                    <div class="col-md-6">
                                                        <img src="inner/img/AA.png" alt="ss">
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </section>
                    </div>
                    <div class="tab-pane" id="2a">
                            <div class="pg secretDelievery" data-aos="fade-down">
                                <div class="container">
                                    <div class="row">
                                        <div class="col-md-12 text-center">
                                            <h2 class="title">The CustomWebnLogoDesign Process of App Development.</h2>
                                            <p>Our streamlined and productive process of mobile app development is what makes us the supreme mobile app development company, Houston. </p>
                                            <ul class="list-center">
                                                <li>
                                                    <i class="sprite_1 sprite-sQ"></i>
                                                    <h4>Fill out our simple questionnaire</h4>
                                                    <p>Give Us The Deets! - Fill out the questionnaire provided and try to give us as much information as possible.</p>
                                                </li>
                                                <li>
                                                    <i class="sprite_1 sprite-appD"></i>
                                                    <h4>App <br>Designing</h4>
                                                    <p>App Design! - Determine the aesthetics of your digital platform.</p>
                                                </li>
                                                <li>
                                                    <i class="sprite_1 sprite-dR1"></i>
                                                    <h4>App <br>Development</h4>
                                                    <p>Development! - Our team works tirelessly to deliver your vision to you as soon as possible.</p>
                                                </li>
                                                <li>
                                                    <i class="sprite_1 sprite-aT"></i>
                                                    <h4>App <br>Testing</h4>
                                                    <p>Beta Testing! - After an app design is approved and the application is developed, it will be tested for bugs and glitches through countless usage so you can rest assured.</p>
                                                </li>
                                                <li>
                                                    <i class="sprite_1 sprite-pD"></i>
                                                    <h4>Project <br>Delivery</h4>
                                                    <p>Deploy! - After all is said and done, the only thing that remains is to inaugurate the launching of your website.</p>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>
                    </div>
                    <div class="tab-pane" id="3a">
                            <div class="pg secretDelievery" data-aos="fade-up">
                                <div class="container">
                                    <div class="row">
                                        <div class="col-md-12 text-center">
                                            <h2 class="title">FAQS</h2>
                                            <p>
                                                The most common questions related to app development
                                            </p>
                                            <ul class="arrow-list">
                                                <li>
                                                    <h4>Does your business even need an app?</h4>
                                                    <p>Smartphones are widely available nowadays. It only makes sense that to reach all potential customers, an app should go mobile regardless of the type of business. Best for marketing and branding solutions.</p>
                                                </li>
                                                <li>
                                                    <h4>Turnaround time of a mobile app?</h4>
                                                    <p>It takes around 1 month to completely develop your mobile app.</p>
                                                </li>
                                                <li>
                                                    <h4>What type of mobile app should I get?</h4>
                                                    <p>There are multiple creative ways we can use mobile apps to upgrade your business. Check out our pages to learn more or simply reach out to us. We’ll be more than happy to assist you.</p>
                                                </li>
                                                <li>
                                                    <h4>What if I don't like my app?</h4>
                                                    <p>Unlimited Revisions till Complete Customer Satisfaction. Enough said. 
                                                    </p>
                                                </li>
                                                <li>
                                                    <h4>I hate the app I have right now, anything you can do about it?</h4>
                                                    <p>No problem! We can make brand new apps for you to cater to your needs.
                                                    </p>
                                                </li>
                                                <li>
                                                    <h4>How do I get started?</h4>
                                                    <p>Contact us now. The information is available on our website.</p>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>
                    </div>
                </div>
            </div>
         <?php
            require_once("include/inner-counter.php");
            require_once("include/contact.php");
            require_once("include/client.php");
            ?>
        </main>
<!--subscribe-->
<form method="post" id="sub">
            <section class="subscribe container-fluid">
                <div class="container">
                    <div class="row">
                        <div class="col-xl-5 text-center">
                            <h3>Looking for the finest mobile app development company, Houston, Texas? Here we are.</h3>
                        </div>
                        <div class="col-xl-7">
                            <div class="input-container">
                                <i class="fa fa-envelope-o sub-icon" aria-hidden="true"></i>
                                <input name="email" class="input-field" type="email" placeholder="Enter Email Address..." required>
                                <div class="sub-btn-back">
                                <input  class="sub-btn" type="submit" name="" value="LET'S START"></div>
                               
                            </div>

                        </div>
                    </div>
                </div>
            </section>

             </form>
            <!--subscribe end-->
        <?php
            require_once("include/footer.php");
            require_once("include/script.php");
?>
</body>
</html>
    
    <script>
        $(window).bind('load resize', function () {
                    // $('#parent').append('<div>hello</div>');    
                    var viewWidth = $(window).width();
                    if(viewWidth > 767){
                        $('#serviceSlider').on('afterChange', function(slick, currentSlide){
                        var get_index = currentSlide.currentSlide;
                        switch(get_index){
                            case 0:
                                $(this).find('img').after('<img src="inner/img/ss-bg.png" class="bg-img">');
                                break;
                            case 1:
                                $(this).find('img').after('<img src="inner/img/IOS-bg.png" class="bg-img">');
                                break;
                            case 2:
                                $(this).find('img').after('<img src="inner/img/AA-bg.png" class="bg-img">');
                                break;
                        }
                        });
                        $('#serviceSlider').on('beforeChange', function (slick, currentSlide, nextSlide) {
                            var get_index = currentSlide.currentSlide;
                            switch(get_index){
                                case 0:
                                    $(this).find('img.bg-img').remove();
                                    break;
                                case 1:
                                    $(this).find('img.bg-img').remove();
                                    break;
                                case 2:
                            }                          
                        });
                        $('#serviceSlider').find('img').after('<img src="inner/img/ss-bg.png" class="bg-img">');
                    }
                })
    </script>