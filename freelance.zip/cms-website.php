<!DOCTYPE html>
<html lang="en">
    <head>
<title>CMS Website - Custom Web N Logo Design</title>
        <?php
            require_once("include/head.php");
        ?>
        <link rel="stylesheet" href="css/inner-custom.css">
    </head>
    <body>
       <?php
            require_once("include/nav.php");
        ?>
                <main>
            <section class="banner">
                <div class="banner-img">
                    <img src="inner/img/banner_print.jpg" alt="banner">
                </div>
                <div class="banner-content no-bg">
                    <div class="container">
                        <div class="row">
                            <div class="col-lg-6 col-12">
                                <div class="row">
                                    <div class="col">
                                        <i class="sprite_1 sprite-Lban1" data-aos="fade-up"></i>
                                    </div>
                                    <div class="col" data-aos="fade-up">
                                        <i class="sprite_1 sprite-Lban2"></i>
                                    </div>
                                    <div class="col" data-aos="fade-up">
                                        <i class="sprite_1 sprite-Lban3"></i>
                                    </div>
                                    <div class="col-12">
                                        <div class="service-desc" data-aos="fade-left">
                                            <h2>
                                               QUALITY PRINT DESIGNS  
                                                <span>AT AFFORDABLE PRICES </span>
                                            </h2>
                                            <button class="btn btn-rounded btn-white-outline">Upto 70% off on all packages!</button>
                                            <div class="col-12 col-md-6 p-0">
                                                <a href="javascript:void(0);" class="btn btn-rounded btn-black popupBox d-lg-none d-block" data-toggle="modal" data-target="getQuote">lets get started</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <?php
                                require_once("include/inner-top-form.php");
                            ?>
                        </div>
                    </div>
                </div>
            </section>

            <div id="exTab1">	
                <div class="middle-nav">
                    <ul class="nav nav-pills">
                        <li class="active">
                            <a  href="#1a" class="active" data-toggle="tab">CMS Website Design</a>
                        </li>
                        <li>
                            <a  href="#2a" data-toggle="tab">CMS Website package</a>
                        </li>
                        <li>
                            <a  href="#3a" data-toggle="tab">CMS Website process</a>
                        </li>
                        <li>
                            <a href="#4a" data-toggle="tab">faqs</a>
                        </li>
                    </ul>
                </div>
                <div class="tab-content clearfix">
                    <div class="tab-pane active" id="1a">
                            <?php
                               require_once("include/about.php");
                            ?>  
                            <section class="pg glimpse" data-aos="fade-down">
                                <div class="container">
                                    <div class="row">
                                        <div class="col-12 text-center">
                                            <h2 class="title">A Glimpse Of Our Works</h2>
                                            <p>What we do is simply far superior than others</p>
                                            <ul class="tabs d-none" id="glimpse">
                                                <li class="tab-link current" data-tab="tab-1">All</li>
                                                <li class="tab-link" data-tab="tab-2">Lorem Ipsum</li>
                                                <li class="tab-link" data-tab="tab-3">Lorem Ipsum</li>
                                                <li class="tab-link" data-tab="tab-4">Lorem Ipsum</li>
                                                <li class="tab-link" data-tab="tab-5">Lorem Ipsum</li>
                                                <li class="tab-link" data-tab="tab-5">Lorem Ipsum</li>
                                                <li class="tab-link" data-tab="tab-5">Lorem Ipsum</li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                                <div class="container-fluid">
                                    <div class="row">
                                        <div class="tab-content current" id="tab-1">
                                            <div class="workGal">
                                            <ul class="workList">
                                                <li class="first"><a href="assets/cms/1.jpg" class="image-link"><i class="fa fa-search"></i></a><img src="assets/cms/1.jpg" alt=""></li>
                                                <li><a href="assets/cms/2.png" class="image-link"><i class="fa fa-search"></i></a><img src="assets/cms/2.png" alt=""></li>
                                                <li><a href="assets/cms/3.jpg" class="image-link"><i class="fa fa-search"></i></a><img src="assets/cms/3.jpg" alt=""></li>
                                                <li><a href="assets/cms/4.jpg" class="image-link"><i class="fa fa-search"></i></a><img src="assets/cms/4.jpg" alt=""></li>
                                                <li><a href="assets/cms/5.jpg" class="image-link"><i class="fa fa-search"></i></a><img src="assets/cms/5.jpg" alt=""></li>
                                                
                                            </ul>
                                            </div>
                                        </div>
                                        <div class="tab-content" id="tab-2">
                                            <div class="workGal">
                                                <ul class="workList">
                                                    <li><img src="inner/img/pp6.png" alt=""></li>
                                                    <li><img src="inner/img/pp7.png" alt=""></li>
                                                    <li><img src="inner/img/pp8.png" alt=""></li>
                                                    <li><img src="inner/img/pp9.png" alt=""></li>
                                                    <li><img src="inner/img/pp10.png" alt=""></li>
                                                    <li><img src="inner/img/pp1.png" alt=""></li>
                                                    <li><img src="inner/img/pp2.png" alt=""></li>
                                                    <li><img src="inner/img/pp3.png" alt=""></li>
                                                    <li><img src="inner/img/pp4.png" alt=""></li>
                                                    <li><img src="inner/img/pp5.png" alt=""></li>
                                                </ul>
                                            </div>
                                        </div>
                                        <div class="tab-content" id="tab-3">
                                            <div class="workGal">
                                                <ul class="workList">
                                                    <li><img src="inner/img/pp4.png" alt=""></li>
                                                    <li><img src="inner/img/pp5.png" alt=""></li>
                                                    <li><img src="inner/img/pp6.png" alt=""></li>
                                                    <li><img src="inner/img/pp1.png" alt=""></li>
                                                    <li><img src="inner/img/pp2.png" alt=""></li>
                                                    <li><img src="inner/img/pp3.png" alt=""></li>
                                                    <li><img src="inner/img/pp7.png" alt=""></li>
                                                    <li><img src="inner/img/pp8.png" alt=""></li>
                                                    <li><img src="inner/img/pp9.png" alt=""></li>
                                                    <li><img src="inner/img/pp10.png" alt=""></li>
                                                </ul>
                                            </div>
                                        </div>
                                        <div class="tab-content" id="tab-4">
                                            <div class="workGal">
                                                <ul class="workList">
                                                    <li><img src="inner/img/pp1.png" alt=""></li>
                                                    <li><img src="inner/img/pp2.png" alt=""></li>
                                                    <li><img src="inner/img/pp3.png" alt=""></li>
                                                    <li><img src="inner/img/pp4.png" alt=""></li>
                                                    <li><img src="inner/img/pp5.png" alt=""></li>
                                                    <li><img src="inner/img/pp6.png" alt=""></li>
                                                    <li><img src="inner/img/pp7.png" alt=""></li>
                                                    <li><img src="inner/img/pp8.png" alt=""></li>
                                                    <li><img src="inner/img/pp9.png" alt=""></li>
                                                    <li><img src="inner/img/pp10.png" alt=""></li>
                                                </ul>
                                            </div>
                                        </div>
                                        <div class="tab-content" id="tab-5">
                                            <div class="workGal">
                                                <ul class="workList">
                                                    <li><img src="inner/img/pp6.png" alt=""></li>
                                                    <li><img src="inner/img/pp7.png" alt=""></li>
                                                    <li><img src="inner/img/pp8.png" alt=""></li>
                                                    <li><img src="inner/img/pp9.png" alt=""></li>
                                                    <li><img src="inner/img/pp10.png" alt=""></li>
                                                    <li><img src="inner/img/pp1.png" alt=""></li>
                                                    <li><img src="inner/img/pp2.png" alt=""></li>
                                                    <li><img src="inner/img/pp3.png" alt=""></li>
                                                    <li><img src="inner/img/pp4.png" alt=""></li>
                                                    <li><img src="inner/img/pp5.png" alt=""></li>
                                                </ul>
                                            </div>
                                        </div>
                                        <div class="tab-content" id="tab-6">
                                            <div class="workGal">
                                                <ul class="workList">
                                                    <li><img src="inner/img/pp4.png" alt=""></li>
                                                    <li><img src="inner/img/pp5.png" alt=""></li>
                                                    <li><img src="inner/img/pp6.png" alt=""></li>
                                                    <li><img src="inner/img/pp1.png" alt=""></li>
                                                    <li><img src="inner/img/pp2.png" alt=""></li>
                                                    <li><img src="inner/img/pp3.png" alt=""></li>
                                                    <li><img src="inner/img/pp7.png" alt=""></li>
                                                    <li><img src="inner/img/pp8.png" alt=""></li>
                                                    <li><img src="inner/img/pp9.png" alt=""></li>
                                                    <li><img src="inner/img/pp10.png" alt=""></li>
                                                </ul>
                                            </div>
                                        </div>
                                        <div class="tab-content" id="tab-7">
                                            <div class="workGal">
                                                <ul class="workList">
                                                    <li><img src="inner/img/pp1.png" alt=""></li>
                                                    <li><img src="inner/img/pp2.png" alt=""></li>
                                                    <li><img src="inner/img/pp3.png" alt=""></li>
                                                    <li><img src="inner/img/pp4.png" alt=""></li>
                                                    <li><img src="inner/img/pp5.png" alt=""></li>
                                                    <li><img src="inner/img/pp6.png" alt=""></li>
                                                    <li><img src="inner/img/pp7.png" alt=""></li>
                                                    <li><img src="inner/img/pp8.png" alt=""></li>
                                                    <li><img src="inner/img/pp9.png" alt=""></li>
                                                    <li><img src="inner/img/pp10.png" alt=""></li>
                                                </ul>
                                            </div>
                                        </div>                                        
                                    </div>
                                </div>
                            </section>
                            <section class="pg" data-aos="fade-up">
                                <div class="container">
                                    <div class="row">
                                        <div class="col-12">
                                            <ul class="list-center">
                                                <li><a href="#" class="btn btn-rounded btn-black btn-block btn-lg popupBox" data-toggle="modal" data-target="getQuote">lets get started</a></li>
                                                <li><a href="#" class="btn btn-rounded btn-white-outline active chatt btn-lg">chat now</a></li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </section>
                            <section class="pg bg-grey" data-aos="fade-down">
                                <div class="container">
                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="text-center">
                                                <h2 class="title">Only The Best CMS Website Services</h2>
                                                <p>We don't compromise on quality and keep the essence of your CMS Website intact.</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="large-img">
                                    <div class="image-50 ml-auto">
                                        <img src="inner/img/printing.png" alt="printing">
                                    </div>
                                    <div class="container">
                                        <div class="col-lg-6 col-12">
                                            <ul class="tick-list">
                                                <li>
                                                        <i class="sprite_1 sprite-tick"></i>
                                                    <div class="listDesc">
                                                        <h4>Save Money &amp; Time</h4>
                                                        <p>
                                                            Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.
                                                        </p>
                                                    </div>
                                                </li>
                                                <li>
                                                        <i class="sprite_1 sprite-tick"></i>
                                                    <div class="listDesc">
                                                        <h4>More Creativity</h4>
                                                        <p>
                                                            Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.                                                        
                                                        </p>
                                                    </div>
                                                </li>
                                                <li>
                                                        <i class="sprite_1 sprite-tick"></i>
                                                    <div class="listDesc">
                                                        <h4>Dedicated Account Managers</h4>
                                                        <p>
                                                            Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.                                                        
                                                        </p>
                                                    </div>
                                                </li>
                                                <li>
                                                        <i class="sprite_1 sprite-tick"></i>
                                                    <div class="listDesc">
                                                        <h4>Money Back Guarantee*</h4>
                                                        <p>
                                                            Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.
                                                        </p>
                                                    </div>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </section>
                    </div>
                    <div class="tab-pane" id="2a">
                            <div class="pg secretDelievery">
                                <div class="container">
                                    <div class="row">
                                        <div class="col-12">
                                            <h2 class="title">Looking for a quality CMS Website</h2>
                                            <p>That converses your brand personality? We offer CMS Website that raise appeal and brand.  </p>
                                            <ul class="creativity">
                                                <li>
                                                    <div class="quote" style="background-image: url('inner/img/revision.png');">
                                                        <i>
                                                            <img src="inner/img/revision.png" alt="quote">
                                                        </i>
                                                        <p>Unlimited Revisions</p>
                                                    </div>
                                                </li>
                                                <li>
                                                    <div class="quote" style="background-image: url('inner/img/ownership.png');">
                                                        <i>
                                                            <img src="inner/img/ownership.png" alt="quote">
                                                        </i>
                                                        <p>100% Ownership Rights</p>
                                                    </div>
                                                </li>
                                                <li>
                                                    <div class="quote" style="background-image: url('inner/img/moneyBack.png');">
                                                        <i>
                                                            <img src="inner/img/moneyBack.png" alt="quote">
                                                        </i>
                                                        <p>100% Money Back Guarantee</p>
                                                    </div>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>
                    <!--section package -->
            <section class="package">
                <div class="text-center">
                    <h2>Reasonable <b>CMS Website Packages</b></h2>
                        <p>Custom Web N Logo Design has reasonably tailored packages suitable for your requirments and budget so we have something for everyone.</p>
                        <?php
                            require_once("package/cms-website-package.php");
                        ?>
                </div>
            </section>
            <br><br>
            <?php
                require_once("include/key.php");
            ?>
        </div>
            <!--section package end -->
                    <div class="tab-pane" id="3a">
                            <div class="pg secretDelievery" data-aos="fade-up">
                                <div class="container">
                                    <div class="row">
                                        <div class="col-md-12 text-center">
                                            <h2 class="title">Our Secret To Always Deliver Above Average</h2>
                                            <p>Lies in our flawless and efficient process, delivering 110% satisfaction!</p>
                                            <ul class="list-center">
                                                <li>
                                                    <i class="sprite_1 sprite-sQ"></i>
                                                    <h4>Fill out our simple questionnaire</h4>
                                                    <p>This helps our experts to analyze the requirements, and take your project in right direction.</p>
                                                </li>
                                                <li>
                                                    <i class="sprite_1 sprite-appD"></i>
                                                    <h4>Design <br>Consultancy</h4>
                                                    <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
                                                </li>
                                                <li>
                                                    <i class="sprite_1 sprite-fD"></i>
                                                    <h4>Print <br>Consultancy</h4>
                                                    <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
                                                </li>
                                                <li>
                                                    <i class="sprite_1 sprite-dR"></i>
                                                    <h4>Unlimited <br>Revision</h4>
                                                    <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
                                                </li>
                                                <li>
                                                    <i class="sprite_1 sprite-pD"></i>
                                                    <h4>Fast <br>Delivery</h4>
                                                    <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>
                    </div>
                    <div class="tab-pane" id="4a">
                        <div class="pg secretDelievery" data-aos="fade-down">
                                <div class="container">
                                    <div class="row">
                                        <div class="col-md-12 text-center">
                                            <h2 class="title">FAQS</h2>
                                            <p>
                                                For All Your General Queries, Go Through Our Detailed FAQS.
                                            </p>
                                            <ul class="arrow-list">
                                                <li>
                                                    <h4>Lorem Ipsum is simply dummy text of the printing and typesetting industry.</h4>
                                                    <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry.Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
                                                </li>
                                                <li>
                                                    <h4>How long does it take to deliver my CMS Website?</h4>
                                                    <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
                                                </li>
                                                <li>
                                                    <h4>Lorem Ipsum is simply dummy text? </h4>
                                                    <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry.Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
                                                </li>
                                                <li>
                                                    <h4>What if I'm not satisfied with the end results?</h4>
                                                    <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry.Lorem Ipsum is simply dummy text of the printing and typesetting industry.Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
                                                </li>
                                                
                                                
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                        </div>
                    </div>
                </div>
            </div>

         <?php
            require_once("include/inner-counter.php");
            require_once("include/contact.php");
            require_once("include/client.php");
            ?>
        </main>
        <!--subscribe-->
<form method="post" id="sub">
            <section class="subscribe container-fluid">
                <div class="container">
                    <div class="row">
                        <div class="col-xl-5 text-center">
                            <h3>Looking for the finest web development company, Houston, Texas? Here we are.</h3>
                        </div>
                        <div class="col-xl-7">
                            <div class="input-container">
                                <i class="fa fa-envelope-o sub-icon" aria-hidden="true"></i>
                                <input name="email" class="input-field" type="email" placeholder="Enter Email Address..." required>
                                <div class="sub-btn-back">
                                <input  class="sub-btn" type="submit" name="" value="LET'S START"></div>
                               
                            </div>

                        </div>
                    </div>
                </div>
            </section>

             </form>
            <!--subscribe end-->
        <?php
            require_once("include/footer.php");
            require_once("include/script.php");
?>
</body>
</html>        

    
    <script>
        $(document).ready(function(){
            var getImgHeight= $('.image-50').height();
            var childHeight= $('.image-50').parents('.large-img').find('.tick-list').height();
            if(getImgHeight > childHeight){
                $('.image-50').parents('.large-img').css('height', getImgHeight+'px')
            }
        })
    </script>
    