<?php
	$con = mysqli_connect("localhost","root","","freelance");
	// Check connection
	if ($con -> connect_errno) {
	  echo "Failed to connect to Database: " . $$con -> connect_error;
	  exit();
	}
?>