<?php
if(!empty($_SERVER['HTTP_X_REQUESTED_WITH']) 
   && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest') 
{
	require_once("../admin_panel/connection.php");
	if(isset($_GET['quote']))
	{
		$name=$_POST['name'];
		$email=$_POST['email'];
		$country_code=str_replace(":  ", " : +", $_GET['quote']);
		$phone=$country_code." ".$_POST['phone'];
		$insert=mysqli_query($con,"insert into quote (name,email,phone,mark_read,date) values('".$name."','".$email."','".$phone."','false','".date("d/m/Y")."')");
		if($insert)
		{
			echo "You quote has been submited our consultant will contact you soon";
			$subject = "You have received new quote";
			$msg = "Name : ".$name."<br> Email : ".$email."<br> Phone : ".$phone;
			include '../smtp/mail.php';
		}
		else
		{
			echo "Please try again something went wrong";
		}
	}
	if(isset($_GET['sub']))
	{
		$check = mysqli_query($con,"select * from subscribers where email='".$_POST['email']."'");
		if(mysqli_num_rows($check) == 0)
		{
			$insert=mysqli_query($con,"insert into subscribers (email,date) values ('".$_POST['email']."','".date("d/m/Y")."')");
			if($insert)
			{
				echo "Thank you for subscribe now you'll get all the new updates related our website.";
				$subject = "Subscriber";
				$msg = "New Subscriber : ".$_POST['email'];
				include '../smtp/mail.php';
			}
			else
			{
				echo "Please try again something went wrong";
			}
		}
		else
		{
			echo "You are already our subscriber";
		}
	}
}
?>