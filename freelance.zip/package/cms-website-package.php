<div class="package-slide owl-carousel owl-theme cms-website-package">
	<?php
		$fetch=mysqli_query($con,"select * from packages where package_name='CMS WEBSITE' order by id desc");
		while ($row=mysqli_fetch_array($fetch)) {
	?>
	<div class="slide-item">
		<div class="package-box package-box-blue">
			<div class="package-box-head package-box-head-blue">
				<div class="hr"></div>
				<?php
					if($row['package_sell_price']!=null)
					{
						$sell_price="$".$row['package_sell_price'];
						$actule_price="$".$row['package_price'];
					}
					else
					{
						$sell_price="$".$row['package_price'];
						$actule_price=$row['package_sell_price'];
					}
				?>
				<span class="package-price-sell"><?=$sell_price?></span>
				<span class="package-price"><del><?=$actule_price?></del></span>
			</div>
		<div class="package-top-btn-div">
			<a href="order/order-now?id=<?=$row['id']?>" class="package-top-btn package-top-btn-blue"><?=$row['package_level']?></a>
		</div>
		</div>
		<div class="package-heading package-heading-blue">
			<div class="package-heading-top-white"></div>
			<h3><?=$row['package_heading1']?></h3>
			<p><i><?=$row['package_heading2']?></i></p>
			<div class="package-heading-bottom-white"></div>
		</div>
		<div class="package-middle-box package-middle-box-blue">
			<div class="package-details">
				<p><?=$row['package_details']?></p>
			</div>
			<div class="package-bottom">
				<button class="package-bottom-btn1" onclick="order_id(<?=$row['id']?>)">ORDER NOW</button>
				<a href="packages" class="package-bottom-btn2">SEE ALL PACKAGES</a>
			</div>
			<a href="#" class="package-talk">
			<i class="fa fa-comments-o" aria-hidden="true"></i>TALK TO US</a>
		</div>
	</div>
	<?php
	}
	?>						
</div>