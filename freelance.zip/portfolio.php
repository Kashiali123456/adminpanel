<!DOCTYPE html>
<html lang="en">
    <title>Portfolio - Custom Web N Logo Design</title>
        <?php
            require_once("include/head.php");
        ?>
        <link rel="stylesheet" href="css/inner-custom.css">
    </head>
    <body>
       <?php
            require_once("include/nav.php");
        ?>
               <mian>
    <section class="banner">
        <div class="banner-img">
            <img src="inner/img/portfolio-banner.jpg" alt="banner">
        </div>
        <div class="banner-content no-bg">
            <div class="container">
                <div class="row">
                    <div class="col-lg-6 col-12">
                        <div class="row">
                            <div class="col-12">
                                <div class="service-desc">
                                    <h2>
                                        Our Portfolio
                                    </h2>
                                    <p>
                                    Whatever we do, we simply aim to take it above average. Our portfolio displays some of our successful projects over the years.
                                    </p>
                            </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-5 col-12"></div>
                </div>
            </div>
        </div>
    </section>
    		<section class="pg glimpse mt-5 mb-5" data-aos="fade-down">
                                <div class="container">
                                    <div class="row">
                                        <div class="col-12 text-center">
                                            <h2 class="title">A Glimpse Of Our Works</h2>
                                            <p>What we do is simply far superior than others</p>
                                            <ul class="tabs" id="glimpse">
                                                <li class="tab-link current" data-tab="tab-1">LOGO</li>
                                                <li class="tab-link" data-tab="tab-2">CMS WEBSITE</li>
                                                <li class="tab-link" data-tab="tab-3">WEBSITE</li>
                                                <li class="tab-link" data-tab="tab-4">E-COMMERCE</li>
                                                <li class="tab-link" data-tab="tab-5">APPS</li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                                <div class="container-fluid">
                                    <div class="row">
                                        <div class="tab-content current" id="tab-1">
                                            <div class="workGal">
                                            <ul class="workList">
                                                <li class="first"><a href="assets/logo/1.jpg" class="image-link"><i class="fa fa-search"></i></a><img src="assets/logo/1.jpg" alt=""></li>
                                                <li><a href="assets/logo/2.jpg" class="image-link"><i class="fa fa-search"></i></a><img src="assets/logo/2.jpg" alt=""></li>
                                                <li><a href="assets/logo/3.jpg" class="image-link"><i class="fa fa-search"></i></a><img src="assets/logo/3.jpg" alt=""></li>
                                                <li><a href="assets/logo/4.jpg" class="image-link"><i class="fa fa-search"></i></a><img src="assets/logo/4.jpg" alt=""></li>
                                                <li><a href="assets/logo/5.jpg" class="image-link"><i class="fa fa-search"></i></a><img src="assets/logo/5.jpg" alt=""></li>
                                                <li class="first"><a href="assets/logo/6.png" class="image-link"><i class="fa fa-search"></i></a><img src="assets/logo/6.png" alt=""></li>
                                                <li><a href="assets/logo/7.jpg" class="image-link"><i class="fa fa-search"></i></a><img src="assets/logo/7.jpg" alt=""></li>
                                                <li><a href="assets/logo/8.jpg" class="image-link"><i class="fa fa-search"></i></a><img src="assets/logo/8.jpg" alt=""></li>
                                                <li><a href="inner/img/lp9.jpg" class="image-link"><i class="fa fa-search"></i></a><img src="inner/img/lp9.jpg" alt=""></li>
                                                <li><a href="inner/img/lp10.jpg" class="image-link"><i class="fa fa-search"></i></a><img src="inner/img/lp10.jpg" alt=""></li>
                                                
                                            </ul>
                                            </div>
                                        </div>
                                        <div class="tab-content" id="tab-2">
                                            <div class="workGal">
                                                <ul class="workList">
                                                     <li class="first"><a href="assets/cms/1.jpg" class="image-link"><i class="fa fa-search"></i></a><img src="assets/cms/1.jpg" alt=""></li>
                                                <li><a href="assets/cms/2.png" class="image-link"><i class="fa fa-search"></i></a><img src="assets/cms/2.png" alt=""></li>
                                                <li><a href="assets/cms/3.jpg" class="image-link"><i class="fa fa-search"></i></a><img src="assets/cms/3.jpg" alt=""></li>
                                                <li><a href="assets/cms/4.jpg" class="image-link"><i class="fa fa-search"></i></a><img src="assets/cms/4.jpg" alt=""></li>
                                                <li><a href="assets/cms/5.jpg" class="image-link"><i class="fa fa-search"></i></a><img src="assets/cms/5.jpg" alt=""></li>
                                                </ul>
                                            </div>
                                        </div>
                                        <div class="tab-content" id="tab-3">
                                            <div class="workGal">
                                                <ul class="workList">
                                                <li class="first"><a href="assets/website/1.jpg" class="image-link"><i class="fa fa-search"></i></a><img src="assets/website/1.jpg" alt=""></li>
                                                <li><a href="assets/website/2.png" class="image-link"><i class="fa fa-search"></i></a><img src="assets/website/2.png" alt=""></li>
                                                <li><a href="assets/website/3.jpg" class="image-link"><i class="fa fa-search"></i></a><img src="assets/website/3.jpg" alt=""></li>
                                                <li><a href="assets/website/4.jpg" class="image-link"><i class="fa fa-search"></i></a><img src="assets/website/4.jpg" alt=""></li>
                                                <li><a href="assets/website/5.png" class="image-link"><i class="fa fa-search"></i></a><img src="assets/website/5.png" alt=""></li>
                                                <li class="first"><a href="assets/website/6.jpg" class="image-link"><i class="fa fa-search"></i></a><img src="assets/website/6.jpg" alt=""></li>
                                                <li><a href="assets/website/7.jpg" class="image-link"><i class="fa fa-search"></i></a><img src="assets/website/7.jpg" alt=""></li>
                                                <li><a href="assets/website/8.png" class="image-link"><i class="fa fa-search"></i></a><img src="assets/website/8.png" alt=""></li>
                                                </ul>
                                            </div>
                                        </div>
                                        <div class="tab-content" id="tab-4">
                                            <div class="workGal">
                                                <ul class="workList">
                                                <li class="first"><a href="assets/ecommerce/1.jpg" class="image-link"><i class="fa fa-search"></i></a><img src="assets/ecommerce/1.jpg" alt=""></li>
                                                <li><a href="assets/ecommerce/2.jpg" class="image-link"><i class="fa fa-search"></i></a><img src="assets/ecommerce/2.jpg" alt=""></li>
                                                <li><a href="assets/ecommerce/3.jpg" class="image-link"><i class="fa fa-search"></i></a><img src="assets/ecommerce/3.jpg" alt=""></li>
                                                <li><a href="assets/ecommerce/4.jpg" class="image-link"><i class="fa fa-search"></i></a><img src="assets/ecommerce/4.jpg" alt=""></li>
                                                <li><a href="assets/ecommerce/5.jpg" class="image-link"><i class="fa fa-search"></i></a><img src="assets/ecommerce/5.jpg" alt=""></li>
                                                <li class="first"><a href="assets/ecommerce/6.png" class="image-link"><i class="fa fa-search"></i></a><img src="assets/ecommerce/6.png" alt=""></li>
                                                <li><a href="assets/ecommerce/7.jpg" class="image-link"><i class="fa fa-search"></i></a><img src="assets/ecommerce/7.jpg" alt=""></li>
                                                <li><a href="assets/ecommerce/8.jpg" class="image-link"><i class="fa fa-search"></i></a><img src="assets/ecommerce/8.jpg" alt=""></li>
                                                <li><a href="assets/ecommerce/9.jpg" class="image-link"><i class="fa fa-search"></i></a><img src="assets/ecommerce/9.jpg" alt=""></li>
                                                <li><a href="assets/ecommerce/10.jpg" class="image-link"><i class="fa fa-search"></i></a><img src="assets/ecommerce/10.jpg" alt=""></li>
                                                </ul>
                                            </div>
                                        </div>
                                        <div class="tab-content" id="tab-5">
                                            <div class="workGal">
                                                <ul class="workList">
                                                <li><a href="inner/img/w1.jpg" class="image-link"><i class="fa fa-search"></i></a><img src="inner/img/w1.jpg" alt=""></li>
                                                <li><a href="inner/img/w2.jpg" class="image-link"><i class="fa fa-search"></i></a><img src="inner/img/w2.jpg" alt=""></li>
                                                <li><a href="inner/img/w3.jpg" class="image-link"><i class="fa fa-search"></i></a><img src="inner/img/w3.jpg" alt=""></li>
                                                <li><a href="inner/img/w4.jpg" class="image-link"><i class="fa fa-search"></i></a><img src="inner/img/w4.jpg" alt=""></li>
                                                <li><a href="inner/img/w5.jpg" class="image-link"><i class="fa fa-search"></i></a><img src="inner/img/w5.jpg" alt=""></li>
                                                <li><a href="inner/img/w6.jpg" class="image-link"><i class="fa fa-search"></i></a><img src="inner/img/w6.jpg" alt=""></li>
                                                <li><a href="inner/img/w7.jpg" class="image-link"><i class="fa fa-search"></i></a><img src="inner/img/w7.jpg" alt=""></li>
                                                <li><a href="img/w8.jpg" class="image-link"><i class="fa fa-search"></i></a><img src="inner/img/w8.jpg" alt=""></li>
                                                <li><a href="inner/img/w9.jpg" class="image-link"><i class="fa fa-search"></i></a><img src="inner/img/w9.jpg" alt=""></li>
                                                <li><a href="inner/img/w10.jpg" class="image-link"><i class="fa fa-search"></i></a><img src="inner/img/w10.jpg" alt=""></li>
                                                </ul>
                                            </div>
                                        </div>
                                                                               
                                    </div>
                                </div>
                            </section>

            <?php
            require_once("include/inner-counter.php");
            require_once("include/contact.php");
            require_once("include/client.php");
            ?>
        </main>
        <!--subscribe-->
<form method="post" id="sub">
			<section class="subscribe container-fluid">
				<div class="container">
					<div class="row">
						<div class="col-xl-5 text-center">
							<h3>Looking for the finest web development company, Houston, Texas? Here we are.</h3>
						</div>
						<div class="col-xl-7">
							<div class="input-container">
							    <i class="fa fa-envelope-o sub-icon" aria-hidden="true"></i>
							    <input name="email" class="input-field" type="email" placeholder="Enter Email Address..." required>
							    <div class="sub-btn-back">
							    <input  class="sub-btn" type="submit" name="" value="LET'S START"></div>
							   
						  	</div>

						</div>
					</div>
				</div>
			</section>

			 </form>
			<!--subscribe end-->
        <?php
            require_once("include/footer.php");
            require_once("include/script.php");
?>
</body>
</html>