<!DOCTYPE html>
<html lang="en">
    <head>
<title>SEO - Custom Web N Logo Design</title>

        <?php
            require_once("include/head.php");
        ?>
        <meta name="title" content="SEO Company Houston – Local SEO services in Houston, TX">
        <meta name="description" content="Looking for an affordable SEO Company? Our SEO Experts provide top-notch SEO services in Houston, TX. Call now or get 70% off on all SEO packages.">
        <link rel="stylesheet" href="css/inner-custom.css">
    </head>
    <body>
       <?php
            require_once("include/nav.php");
        ?>
                <main>
            <section class="banner">
                <div class="banner-img">
                    <img src="inner/img/banner_seo.jpg" alt="banner">
                </div>
                <div class="banner-content no-bg">
                    <div class="container">
                        <div class="row">
                            <div class="col-lg-6 col-12">
                                <div class="row">
                                    <div class="col" data-aos="fade-up">
                                        <i class="sprite_1 sprite-SEban1"></i>
                                    </div>
                                    <div class="col" data-aos="fade-up">
                                        <i class="sprite_1 sprite-SEban2"></i>
                                    </div>
                                    <div class="col" data-aos="fade-up">
                                        <i class="sprite_1 sprite-SEban3"></i>
                                    </div>
                                    <div class="col-12">
                                        <div class="service-desc" data-aos="fade-left">
                                            <h2>
                                                Reach for the top with Houston SEO Company 
                                                <span>Book your top spot with our SEO services in Houston, TX</span>
                                            </h2>
                                            <button class="btn btn-rounded btn-white-outline">Upto 70% off on all packages!</button>
                                            <div class="col-12 col-md-6 p-0">
                                                <a href="javascript:void(0);" class="btn btn-rounded btn-black popupBox d-lg-none d-block" data-toggle="modal" data-target="getQuote">lets get started</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <?php
                                require_once("include/inner-top-form.php");
                            ?>
                        </div>
                    </div>
                </div>
            </section>
            <div id="exTab1">	
                <div class="middle-nav">
                    <ul class="nav nav-pills">
                        <li class="active">
                            <a  href="#1a" class="active" data-toggle="tab">SEO overview</a>
                        </li>    
                        <li class="">
                            <a  href="#2a" data-toggle="tab">SEO process</a>
                        </li>
                        <li>
                            <a  href="#3a" data-toggle="tab">SEO package</a>
                        </li>
                        <li>
                            <a href="#4a" data-toggle="tab">faqs</a>
                        </li>
                    </ul>
                </div>
                <div class="tab-content clearfix">
                <div class="tab-pane active" id="1a">
                            <!-- section one -->
            <section class="mt-5 pg whyUs"  data-aos="fade-up">
                <div class="container-fluid section-one">
                    <div class="row">
                        <div class="col-1 d-none d-xl-block">
                            <div class="about-heading">ABOUT<span>US</span></div>
                        </div>
                        <div class="col-xl-5 col-lg-6 mt-5">
                            <img width="100%" src="assets/section-one.png">
                        </div>
                        <div class="col-xl-5 col-lg-6 mt-5">
                            <div class="section-one-sec">
                            <h3>SEO Company in Houston, TX</h3>
                            <div class="hr"></div>
                            <p><b>Why Invest In SEO (Search Engine Optimization)?</b></p>
                            <p class="color-lightgray section-one-p">
                                The best way to make a name for your business in the market is to perform exceptionally well. But to do that, your presence as a stellar developer must be made on the digital platform. How would clients know about you if you do not give them a platform to evaluate your company? And even if you have a website, how does a potential customer single out your company out of a hundred others showing up on the Google search.   
                                <br>
                                That’s where our SEO services come in. Using Search Engine Optimization, we can make sure that your website contains enough relevant keywords to top the lists of search engines everywhere. Topping the list means your website will generate more traffic. More traffic means you’re raking the majority of the customers towards your webpage. Increased attention would eventually lead to increased profits, all of them will be achieved by our affordable SEO services. There is literally no downside to this. 
                                <br>
                                A client only has to search for a service provider and a well-optimized website will make sure your company’s name comes on top. SEO services of the highest order can be found with Custom Web n Logo Designs operating throughout globally.   
                            </p>
                            </div>
                            <div class="row section-one-box">
                                
                                <div class="col-xl-4 col-lg-6 col-sm-4">
                                <center>
                                <div class="section-one-box1">
                                    <img class="box-icon" src="assets/box-icon1.png">
                                </div>
                                <p>Invest in SEO<img class="section-one-hr" src="assets/hr.png"></p>
                                </center>
                                </div>

                                <div class="col-xl-4 col-lg-6 col-sm-4">
                                <center>
                                <div class="section-one-box2">
                                    <img class="box-icon" src="assets/box-icon2.png">
                                </div>
                                <p>Top all Lists<img class="section-one-hr" src="assets/hr.png"></p>
                                </center>
                                </div>

                                <div class="col-xl-4 col-lg-12 col-sm-4">
                                <center>
                                <div class="section-one-box3 text-center">
                                    <img class="box-icon" src="assets/box-icon3.png">
                                </div>
                                <p>Generate Traffic and Customers!<img class="section-one-hr" src="assets/hr.png"></p>
                                
                                </center>
                                </div>
                            </div>
                        </div>
                        <div class="col-1 d-none d-xl-block">
                            <img width="90%" src="assets/section-one-icon.png">
                        </div>
                        <div class="col-12 text-center section-one-bottom">
                            CUSTOM WEB & LOGO
                        </div>
                    </div>
                </div>
            </section>
            <!-- section one end-->
                            <section class="pg" data-aos="fade-up">
                                <div class="simplerSol">
                                    <div class="container">
                                        <div class="row">
                                            <div class="col-md-12">
                                                <div class="text-center">
                                                    <h2 class="title">Rank on Google with our Local SEO in Houston, TX</h2>
                                                    <p>Make your website the hottest new attraction in town and attract all customers your way with Houston SEO services.</p>
                                                </div>
                                            </div>
                                        </div>
                                        <div id="serviceSlider">
                                            <div class="ss-slider">
                                                <div class="row">
                                                    <div class="col-md-6">
                                                        <h3>Our SEO Services</h3>
                                                        <p>Let’s say a customer is looking for a certain service. He goes to the internet and looks it up. A Google Search asking for a service provider within a specific region would include the name of those websites which generated the most traffic when others, looking for that same service, did the same Google Search. Meaning the more traffic your website gets, the more popular it gets. The more popular it gets, the more potential customers flock at your webpages. More customers leads to more revenue and profit.</p>
                                                        <p>Therefore, SEO services are essential when it comes to developing a website and optimized it by our SEO experts based in Houston. SEO Company usually write the optimized content within the foundation of the website so that it secures its place at the top of the list for a long time to come. </p>
                                                        <ul class="arrow-list">
                                                            <li>Optimized Content.</li>
                                                            <li>Highest rated Keywords inclusion.</li>
                                                            <li>Increased Traffic on Webpages.</li>
                                                        </ul>
                                                    </div>
                                                    <div class="col-md-6">
                                                        <img src="inner/img/SEO-ser.jpg" alt="ss">
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </section>
                            <section class="pg bg-grey">
                                <div class="container">
                                    <div class="row">
                                        <div class="col-12">
                                            <h2 class="title mt-3">How does SEO work?</h2>
                                            <p>
                                                Search Engine Optimization is important for your digital platform. Not only must your website be renowned and rank all lists, it must also have relevant content that potential customers are looking for. If your website is the first one they click but it doesn’t provide the service they are looking for, the customers would back away real quick and go to another one. For many businesses across Houston, SEO Company is associated with Custom Web n Logo Design due to our exemplary performance in providing relevant optimized content that makes their website more attractive. 
                                            </p>
                                        </div>
                                    </div>
                                    <div class="row justify-content-center progressContent">
                                        <div class="col">
                                            <div class="progress-bar" data-percent="83" data-duration="1000" data-color="transparent,#ac0125"></div>
                                            <p>
                                                Of all consumers are inclined towards an online platform for searching for service providers and products.
                                            </p>
                                        </div>
                                        <div class="col">
                                            <div class="progress-bar" data-percent="75" data-duration="1000" data-color="transparent,#2030c9"></div>
                                            <p>
                                            Of all netizens do not even go to the 2nd page of their search results.
                                            </p>
                                        </div>
                                        <div class="col">
                                            <div class="progress-bar" data-percent="75" data-duration="1000" data-color="transparent,#fc430b"></div>
                                            <p>
                                            Of all net surfers bounce back if they don’t find what they are looking for immediately. 
                                            </p>
                                        </div>
                                    </div>
                                </div>
                            </section>
                    </div>
                    <div class="tab-pane" id="2a">
                            <div class="pg secretDelievery" data-aos="fade-up">
                                    <div class="container">
                                        <div class="row">
                                            <div class="col-md-12 text-center">
                                                <h2 class="title">HOW TO ENGAGE THE EXPERTISE OF HOUSTON SEO SERVICES PROVIDER!</h2>
                                                <p>Custom Web n Logo Design is a reliable and highly professional web development company with a strong grip on the fundamentals of SEO, Branding, and digital marketing.<br>Most of our SEO processes follow these steps</p>
                                                <ul class="list-center">
                                                    <li>
                                                        <i class="sprite_1 sprite-sQ"></i>
                                                        <h4>Give us the Deets! </h4>
                                                        <p>You’ll be provided with a questionnaire to fill with your business details and any other information that would help us do our jobs.</p>
                                                    </li>
                                                    <li>
                                                        <i class="sprite_1 sprite-appD"></i>
                                                        <h4>Front-End Optimization</h4>
                                                        <p>Your website will be evaluated by our experts to determine what changes should be made to your website and to determine the scope of the project.</p>
                                                    </li>
                                                    <li>
                                                        <i class="sprite_1 sprite-sES"></i>
                                                        <h4>Search Engine Acceptance</h4>
                                                        <p>The website will be submitted on all search engine lists to be ranked according to the level of optimization the website undergoes.</p>
                                                    </li>
                                                    <li>
                                                        <i class="sprite_1 sprite-oO"></i>
                                                        <h4>Back End Optimization</h4>
                                                        <p>To fully secure your place in the search engine lists, the foundation and the background code of the websites will be corrected and optimized as well to make sure that the job is completely done.</p>
                                                    </li>
                                                    <li>
                                                        <i class="sprite_1 sprite-mO"></i>
                                                        <h4>Surveillance<br></h4>
                                                        <p>After all is said and done, the website will now be monitored and observed to see if it is in a stable position or not.</p>
                                                    </li>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                            </div> 
                    </div>
                    <div class="tab-pane" id="3a">
                            <!--section package -->
            <section class="package">
                <div class="text-center">
                    <h2>Reasonable <b>Design Packages</b></h2>
                        <p>Custom Web N Logo Design has reasonably tailored packages suitable for your requirments and budget so we have something for everyone.</p>
                        <?php
                            require_once("package/logo-package.php");
                        ?>
                </div>
            </section>
            <!--section package end -->
            <br><br>
            <?php
                require_once("include/key.php");
            ?>
                    </div>
                    <div class="tab-pane" id="4a">
                            <div class="pg secretDelievery" data-aos="fade-up">
                                    <div class="container">
                                        <div class="row">
                                            <div class="col-md-12 text-center">
                                                <h2 class="title">Frequently Asked Questions!</h2>
                                                <p>
                                                    FHere’s what is on everyone’s minds when it comes to SEO.
                                                </p>
                                                <ul class="arrow-list">
                                                    <li>
                                                        <h4>How does SEO Work?</h4>
                                                        <p>The working behind SEO is based on keyword analysis, Onsite and Offsite Optimization, link building, social bookmarking and content marketing. All of this helps in brand promotion on all digital platforms.</p>
                                                    </li>
                                                    <li>
                                                        <h4>Am I supposed to provide the keywords for my SEO?</h4>
                                                        <p>That depends really. If you have subscribed to a package which requires us to get the keywords then definitely, you won’t have to. Always best to leave it to the pros.</p>
                                                    </li>
                                                    <li>
                                                        <h4>How long is the turnaround time for SEO?</h4>
                                                        <p>It’s not like a pain relief medication where “you’ll see the difference immediately”. But after SEO has been done, you’ll see the fruits of your investment within a month of operation. </p>
                                                    </li>
                                                    <li>
                                                        <h4>How do I get informed about my SEO progress?</h4>
                                                        <p>You analyze your website to make a detailed weekly report which informs us to the progress and improvements observed.</p>
                                                    </li>
                                                    <li>
                                                        <h4>What is the final product of opting for SEO services?</h4>
                                                        <p>More traffic generation, more customers, more profit. It’s that simple. </p>
                                                    </li>
                                                    
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                    </div>
                </div>
            </div>
                      
            <?php
            require_once("include/inner-counter.php");
            ?>
            <!--section four-->
            <section class="section-four mt-5">
                <div class="section-four-bg">
                <div class="container-fluid curve-down"></div>
                <div class="container text-center">
                    <div class="section-four-content">
                    <h2>Based in Houston, SEO services like ours cannot be found elsewhere!</h2>
                    <h3>Find the best suitable seo package for your business.</h3>
                    <div class="row pt-5">

                        <div class="col-lg-4 section-four-phone">
                            <div class="row">
                            <div class="col-lg-10 col-7">
                                <p class="section-four-call">CALL TOLL FREE<br><a href="tel:+1(307) 381-2030"><span class="color-darkred">+1(307) 381-2030</span></a></p>
                                </div>
                                <div class="col-lg-2 col-5 section-four-call-iconn">
                                    <div class="section-four-phone-icon">
                                    <i class="fa fa-phone" aria-hidden="true"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-4 section-four-btn">
                            <a class="btn section-four-btnn popupBox" data-toggle="modal" data-target="getQuote" href="javascript:">REQUEST A QUOTE</a>
                        </div>
                        <div class="col-lg-4 section-four-chat">
                            <div class="row">
                                <div class="col-5 col-lg-3 section-four-chat-iconn">
                                    <i class="fa fa-comments-o section-four-chat-icon" aria-hidden="true"></i>
                                </div>
                                <div class="col-7 col-lg-9">                                
                                    <p class="section-four-call">NEED HELP ?<br><a href="#"><span class="color-darkred">LIVE CHAT NOW</span></a></p>
                                </div>
                            </div>
                        </div>
                    </div>
                    </div>
                </div>
                <div class="container-fluid curve-up"></div>
                </div>
            </section>
            <!--section four end -->
            <?php
            require_once("include/client.php");
            ?>
        </main>
        <!--subscribe-->
<form method="post" id="sub">
            <section class="subscribe container-fluid">
                <div class="container">
                    <div class="row">
                        <div class="col-xl-5 text-center">
                            <h3>Hello Houston! Affordable SEO Services at your Disposal! Here we are!</h3>
                        </div>
                        <div class="col-xl-7">
                            <div class="input-container">
                                <i class="fa fa-envelope-o sub-icon" aria-hidden="true"></i>
                                <input name="email" class="input-field" type="email" placeholder="Enter Email Address..." required>
                                <div class="sub-btn-back">
                                <input  class="sub-btn" type="submit" name="" value="LET'S START"></div>
                               
                            </div>

                        </div>
                    </div>
                </div>
            </section>

             </form>
            <!--subscribe end-->
        <?php
            require_once("include/footer.php");
            require_once("include/script.php");
?>
</body>
</html>
    

    
    <script>
        $(window).bind('load resize', function () {
                    // $('#parent').append('<div>hello</div>');    
                    var viewWidth = $(window).width();
                    if(viewWidth > 767){
                        $('#serviceSlider').on('afterChange', function(slick, currentSlide){
                        var get_index = currentSlide.currentSlide;
                        switch(get_index){
                            case 0:
                                $(this).find('img').after('<img src="inner/img/SEO-ser-bg.png" class="bg-img">');
                                break;
                        }
                        });
                        $('#serviceSlider').on('beforeChange', function (slick, currentSlide, nextSlide) {
                            var get_index = currentSlide.currentSlide;
                            switch(get_index){
                                case 0:
                                    $(this).find('img.bg-img').remove();
                                    break;
                            }                          
                        });
                        $('#serviceSlider').find('img').after('<img src="inner/img/SEO-ser-bg.png" class="bg-img">');
                    }
                })
    </script>