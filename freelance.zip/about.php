<!DOCTYPE html>
<html lang="en">
    <title>About - Custom Web N Logo Design</title>
        <?php
            require_once("include/head.php");
        ?>
        <link rel="stylesheet" href="css/inner-custom.css">
    </head>
    <body>
       <?php
            require_once("include/nav.php");
        ?>
                <main>
            <section class="banner">
                <div class="banner-img">
                    <img src="inner/img/banner_about.jpg" alt="banner">
                </div>
                <div class="banner-content no-bg">
                    <div class="container">
                        <div class="row">
                            <div class="col-lg-6 col-12">
                                <div class="row">
                                    <div class="col-12">
                                        <div class="service-desc">
                                            <h2>
                                                About the Custom Web N Logo Design
                                            </h2>
                                            <p>
                                                Whatever we do, we simply take it above average with our passion, innovation and dedication. We believe in providing Solutions rather than just services.
                                            </p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-5 col-12">
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            <div class="pg testimonial">
                <div class="container">
                    <div class="row">
                        <div class="col-12 text-center">
                            <h2 class="title">INSPIRED BY INNOVATION, CUSTOMIZED WITH PRECISION.</h2>
                            <p>
                                Welcome to The Custom Web N Logo Design. Where passion meets innovation. We are industry leaders in digital world or marketing and branding because we keep our operations fast, simple and result-driven. The choice of smart US businesses.
                            </p>
                        </div>
                    </div>
                </div>
            </div>

            <div class="evalution">
                <div class="bgImgContent">
                    <div class="container-fluid">
                        <div class="row">
                            <div class="col-md-6 p-0">
                                <img src="inner/img/orange-bg.png" alt="" class="w-100">
                            </div>
                            <div class="col-md-6 p-0">
                                <img src="inner/img/dark-bg.png" alt="" class="w-100">
                            </div>
                        </div>
                    </div>
                </div>
                <div class="container upperText">
                    <div class="row">
                        <div class="col-md-6">
                            <h2 class="title">EVOLUTION, INNOVATION & PRECISION.</h2>
                            <p>Our motto at The Custom Web N Logo Design is to keep evolviong with the ever-evolving trends of industry to always deliver more than what our clients expect from us. We are propelled by our passion to keep our standards above industry's. We understand, estimate and integrate the consumer patterns and demands.</p>
                        </div>
                        <div class="col-md-6">
                            <table>
                                <tbody>
                                    <tr>
                                        <td>
                                            <p>Our vision is to make digital creativity acessible to all, benefiting clients and all the stakeholders.</p>
                                        </td>
                                        <td>
                                            <h3>Vision</h3>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>
                                            <p>Our mission is to provide our clients with the best digital branding experience, saving their time and money.</p>
                                        </td>
                                        <td>
                                            <h3>Mission</h3>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>
                                            <p>
                                                Our promise is cyber security, business integrity and utmost satisfaction to each client.
                                            </p>
                                        </td>
                                        <td>
                                            <h3>Promise</h3>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>  

            <div class="coreValue">
                <div class="container">
                    <div class="row">
                        <div class="col-12 text-center">
                            <h2 class="title">Our Core Values</h2>
                            <p>
                                Our business model stands upon values of
                            </p>
                            <ul class="core-list">
                                <li>
                                    <i class="sprite_1 sprite-commit"></i>
                                    <h4>Commitment</h4>
                                    <p>
                                        Whatever we do, we do with ethical business codes and complete integrity. We make sure to dleiver what we commit under all circumstances.
                                    </p>
                                </li>
                                <li>
                                    <i class="sprite_1 sprite-creativity"></i>
                                    <h4>Creativity</h4>
                                    <p>
                                        We keep our creativity fresh and flowing by hiring and training fresh blood. This young generation of innovators are trained by industry's best.
                                    </p>
                                </li>
                                <li>
                                    <i class="sprite_1 sprite-security"></i>
                                    <h4>Security</h4>
                                    <p>
                                        The digital world has its pros and cons. The major one being security issueswhen dealing with online vendors. We make sure to hold your digital security as first priority.
                                    </p>
                                </li>
                                <li>
                                    <i class="sprite_1 sprite-integrity"></i>
                                    <h4>Integrity</h4>
                                    <p>
                                        Your business is imporrtant to you and the same goes for us. We keep customer satisfaction as a building block of our brand's image. We never compromise on our standards.
                                    </p>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            <?php
            require_once("include/inner-counter.php");
            require_once("include/contact.php");
            require_once("include/client.php");
            ?>
        </main>
        <!--subscribe-->
<form method="post" id="sub">
            <section class="subscribe container-fluid">
                <div class="container">
                    <div class="row">
                        <div class="col-xl-5 text-center">
                            <h3>Looking for the finest web development company, Houston, Texas? Here we are.</h3>
                        </div>
                        <div class="col-xl-7">
                            <div class="input-container">
                                <i class="fa fa-envelope-o sub-icon" aria-hidden="true"></i>
                                <input name="email" class="input-field" type="email" placeholder="Enter Email Address..." required>
                                <div class="sub-btn-back">
                                <input  class="sub-btn" type="submit" name="" value="LET'S START"></div>
                               
                            </div>

                        </div>
                    </div>
                </div>
            </section>

             </form>
            <!--subscribe end-->
        <?php
            require_once("include/footer.php");
            require_once("include/script.php");
?>
</body>
</html>

    