<!DOCTYPE html>
<html lang="en">
    <head>
<title>Social Media Marketing - Custom Web N Logo Design</title>
        <?php
            require_once("include/head.php");
        ?>
        <link rel="stylesheet" href="css/inner-custom.css">
    </head>
    <body>
       <?php
            require_once("include/nav.php");
        ?>
                <main>
            <section class="banner">
                <div class="banner-img">
                    <img src="inner/img/banner_seo.jpg" alt="banner">
                </div>
                <div class="banner-content no-bg">
                    <div class="container">
                        <div class="row">
                            <div class="col-lg-6 col-12">
                                <div class="row">
                                    <div class="col" data-aos="fade-up">
                                        <i class="sprite_1 sprite-SEban1"></i>
                                    </div>
                                    <div class="col" data-aos="fade-up">
                                        <i class="sprite_1 sprite-SEban2"></i>
                                    </div>
                                    <div class="col" data-aos="fade-up">
                                        <i class="sprite_1 sprite-SEban3"></i>
                                    </div>
                                    <div class="col-12">
                                        <div class="service-desc" data-aos="fade-left">
                                            <h2>
                                                WE HAVE WHAT IT TAKES TO 
                                                <span>DOMINATE YOUR RIVALS</span>
                                            </h2>
                                            <button class="btn btn-rounded btn-white-outline">Upto 70% off on all packages!</button>
                                            <div class="col-12 col-md-6 p-0">
                                                <a href="javascript:void(0);" class="btn btn-rounded btn-black popupBox d-lg-none d-block" data-toggle="modal" data-target="getQuote">lets get started</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <?php
                                require_once("include/inner-top-form.php");
                            ?>
                        </div>
                    </div>
                </div>
            </section>
            <div id="exTab1">	
                <div class="middle-nav">
                    <ul class="nav nav-pills">
                        <li class="active">
                            <a  href="#1a" class="active" data-toggle="tab">Social Media Marketing overview</a>
                        </li>    
                        <li class="">
                            <a  href="#2a" data-toggle="tab">Social Media Marketing process</a>
                        </li>
                        <li>
                            <a  href="#3a" data-toggle="tab">Social Media Marketing package</a>
                        </li>
                        <li>
                            <a href="#4a" data-toggle="tab">faqs</a>
                        </li>
                    </ul>
                </div>
                <div class="tab-content clearfix">
                <div class="tab-pane active" id="1a">
                            <?php
                               require_once("include/about.php");
                            ?>
                            <section class="pg" data-aos="fade-up">
                                <div class="simplerSol">
                                    <div class="container">
                                        <div class="row">
                                            <div class="col-md-12">
                                                <div class="text-center">
                                                    <h2 class="title">BETTER Social Media Marketing. FASTER RESULTS. SIMPLER PROCESS.</h2>
                                                    <p>Better and faster results is our motto at The Custom Web N Logo Design. When it comes to Social Media Marketing, it is never too early or too late.</p>
                                                </div>
                                            </div>
                                        </div>
                                        <div id="serviceSlider">
                                            <div class="ss-slider">
                                                <div class="row">
                                                    <div class="col-md-6">
                                                        <h3>Social Media Marketing Services</h3>
                                                        <p>Our Social Media Marketing services can build up your Social Media Marketing strategies from scratch
                                                        or we can boost your current Social Media Marketing campaigns to give your rankings
                                                        the boost it needs. Our experts are experienced in getting your business
                                                        relevant and result-driven traffic, generating more visibility for your
                                                        digital presence. If you want quick and better rankings on leading 
                                                        search engines, The Custom Web N Logo Design is your ideal service provider for
                                                        all Social Media Marketing requirements.</p>
                                                        <ul class="arrow-list">
                                                            <li>Content Marketing</li>
                                                            <li>Website Audit</li>
                                                            <li>Website Optimization</li>
                                                            <li>Link Building</li>
                                                        </ul>
                                                    </div>
                                                    <div class="col-md-6">
                                                        <img src="inner/img/seo-ser.jpg" alt="ss">
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </section>
                            <section class="pg bg-grey">
                                <div class="container">
                                    <div class="row">
                                        <div class="col-12">
                                            <h2 class="title mt-3">What's The Deal With Social Media Marketing?</h2>
                                            <p>
                                                Why is Social Media Marketing important for you online presence and why do you need to invest in professional Social Media Marketing services? These are some of the basic questions that most of the small business owners ask. The importance of Social Media Marketing is evident in the numbers. The Custom Web N Logo Design knows that most of the online consumers don't care about finding the first and most popular website on fast basis but rather finding the right website with the right content that is relevant to their search. Otherwise they bounce back within seconds.
                                            </p>
                                        </div>
                                    </div>
                                    <div class="row justify-content-center progressContent">
                                        <div class="col">
                                            <div class="progress-bar" data-percent="83" data-duration="1000" data-color="transparent,#ac0125"></div>
                                            <p>
                                                Of consumers look prefer online search for their required products or services
                                            </p>
                                        </div>
                                        <div class="col">
                                            <div class="progress-bar" data-percent="75" data-duration="1000" data-color="transparent,#2030c9"></div>
                                            <p>
                                            Of these online consumers don't look past the first page of their search results.
                                            </p>
                                        </div>
                                        <div class="col">
                                            <div class="progress-bar" data-percent="75" data-duration="1000" data-color="transparent,#fc430b"></div>
                                            <p>
                                            Of visitors bounce back within 80 seconds or less if they don't find the page attractive or informative enough.
                                            </p>
                                        </div>
                                    </div>
                                </div>
                            </section>
                    </div>
                    <div class="tab-pane" id="2a">
                            <div class="pg secretDelievery" data-aos="fade-up">
                                    <div class="container">
                                        <div class="row">
                                            <div class="col-md-12 text-center">
                                                <h2 class="title">Our Secret To Always Deliver Above Average</h2>
                                                <p>Lies in our flawless and efficient process, delivering 110% satisfaction!</p>
                                                <ul class="list-center">
                                                    <li>
                                                        <i class="sprite_1 sprite-sQ"></i>
                                                        <h4>Fill out our simple questionnaire</h4>
                                                        <p>This helps our experts to analyze the requirements, and take your project in right direction.</p>
                                                    </li>
                                                    <li>
                                                        <i class="sprite_1 sprite-appD"></i>
                                                        <h4>Onsite <br>Optimization</h4>
                                                        <p>Sometimes the problem lies in the structure of your Website. We quantify what needs to be changed or added.</p>
                                                    </li>
                                                    <li>
                                                        <i class="sprite_1 sprite-sES"></i>
                                                        <h4>Search Engine <br>Submission</h4>
                                                        <p>Your site gets submitted on the serach lists of major search engines and we''ll send you the complete report.</p>
                                                    </li>
                                                    <li>
                                                        <i class="sprite_1 sprite-oO"></i>
                                                        <h4>Offsite <br>Optimization</h4>
                                                        <p>We’ll assess your inbound links &amp; their value. This increases the quality of your online traffice.</p>
                                                    </li>
                                                    <li>
                                                        <i class="sprite_1 sprite-mO"></i>
                                                        <h4>Monitoring<br></h4>
                                                        <p>We provide monitoring to each and every campaign, making sure that everything runs smoothly.</p>
                                                    </li>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                            </div> 
                    </div>
                    <div class="tab-pane" id="3a">
                            <!--section package -->
            <section class="package">
                <div class="text-center">
                    <h2>Reasonable <b>Design Packages</b></h2>
                        <p>Custom Web N Logo Design has reasonably tailored packages suitable for your requirments and budget so we have something for everyone.</p>
                        <?php
                            require_once("package/social-media-package.php");
                        ?>
                </div>
            </section>
            <!--section package end -->
            <br><br>
            <?php
                require_once("include/key.php");
            ?>
                    </div>
                    <div class="tab-pane" id="4a">
                            <div class="pg secretDelievery" data-aos="fade-up">
                                    <div class="container">
                                        <div class="row">
                                            <div class="col-md-12 text-center">
                                                <h2 class="title">FAQS</h2>
                                                <p>
                                                    For All Your General Queries, Go Through Our Detailed FAQS.
                                                </p>
                                                <ul class="arrow-list">
                                                    <li>
                                                        <h4>How does Social Media Marketing Work?</h4>
                                                        <p>Social Media Marketing works on the principles of keyword analysis, off and on-site optimization, link building, social bookmarking and content marketing to increase visibility and positively promote your brand on different online platforms.</p>
                                                    </li>
                                                    <li>
                                                        <h4>Am I supposed to provide the keywords for my Social Media Marketing?</h4>
                                                        <p>Depending on the package you select, you can either add your own keywords or professionals take care of it for you.</p>
                                                    </li>
                                                    <li>
                                                        <h4>How long is the turn around time for Social Media Marketing?</h4>
                                                        <p>There is no turn around time for Social Media Marketing services as it is relatively a long term &amp; ongoing activity. But we guarantee positive effects within a month.</p>
                                                    </li>
                                                    <li>
                                                        <h4>How do I get informed about my Social Media Marketing progress? </h4>
                                                        <p>You get a comprehensive analytical report on a weekly basis, which highlights the progress &amp; improvements of your website.</p>
                                                    </li>
                                                    <li>
                                                        <h4>What is the final product of opting for Social Media Marketing services?</h4>
                                                        <p>Increased and positive traffic. Increased conversion rates. Wider audience. Better sales. These are but few to name.</p>
                                                    </li>
                                                    
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                    </div>
                </div>
            </div>
                      
            <?php
            require_once("include/inner-counter.php");
            require_once("include/contact.php");
            require_once("include/client.php");
            ?>
        </main>
        <!--subscribe-->
<form method="post" id="sub">
            <section class="subscribe container-fluid">
                <div class="container">
                    <div class="row">
                        <div class="col-xl-5 text-center">
                            <h3>Looking for the finest web development company, Houston, Texas? Here we are.</h3>
                        </div>
                        <div class="col-xl-7">
                            <div class="input-container">
                                <i class="fa fa-envelope-o sub-icon" aria-hidden="true"></i>
                                <input name="email" class="input-field" type="email" placeholder="Enter Email Address..." required>
                                <div class="sub-btn-back">
                                <input  class="sub-btn" type="submit" name="" value="LET'S START"></div>
                               
                            </div>

                        </div>
                    </div>
                </div>
            </section>

             </form>
            <!--subscribe end-->
        <?php
            require_once("include/footer.php");
            require_once("include/script.php");
?>
</body>
</html>
    

    
    <script>
        $(window).bind('load resize', function () {
                    // $('#parent').append('<div>hello</div>');    
                    var viewWidth = $(window).width();
                    if(viewWidth > 767){
                        $('#serviceSlider').on('afterChange', function(slick, currentSlide){
                        var get_index = currentSlide.currentSlide;
                        switch(get_index){
                            case 0:
                                $(this).find('img').after('<img src="inner/img/SEO-ser-bg.png" class="bg-img">');
                                break;
                        }
                        });
                        $('#serviceSlider').on('beforeChange', function (slick, currentSlide, nextSlide) {
                            var get_index = currentSlide.currentSlide;
                            switch(get_index){
                                case 0:
                                    $(this).find('img.bg-img').remove();
                                    break;
                            }                          
                        });
                        $('#serviceSlider').find('img').after('<img src="inner/img/SEO-ser-bg.png" class="bg-img">');
                    }
                })
    </script>