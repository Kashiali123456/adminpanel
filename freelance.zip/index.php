<!DOCTYPE html>
		<html class="no-js">

		<head>
			<?php
			  require_once("admin_panel/connection.php");
			?>	
			<title>Home Page - Custom Web N Logo Design</title>
			
			<meta charset="utf-8">
			<meta http-equiv="X-UA-Compatible" content="IE=edge">
			<meta name="viewport" content="width=device-width, initial-scale=1">
			<link rel="shortcut icon" type="image/x-icon" href="assets/fav.ico">
			<link rel="stylesheet" href="inner/bootstrap/4.0.0/css/bootstrap.min.css">
			<link rel="stylesheet" type="text/css" href="fonts/pe-icon-7-stroke/css/pe-icon-7-stroke.css">
			<link rel="stylesheet" type="text/css" href="fonts/font-awesome/css/font-awesome.min.css">
			<link rel="stylesheet" href="inner/css/intlTelInput.min.css">
			<!-- Plugin -->
  			<link rel="stylesheet" type="text/css" href="css/plugin/owlcarousel/owl.theme.default.min.css">
  			<link rel="stylesheet" type="text/css" href="css/plugin/owlcarousel/owl.carousel.min.css">
			<!-- REVOLUTION STYLE SHEETS -->
			<link rel="stylesheet" type="text/css" href="css/rs6.css">
			<!-- custom -->
			<link rel="stylesheet" href="inner/css/main.css">
            <link rel="stylesheet" type="text/css" href="css/style.css">
            <link rel="stylesheet" type="text/css" href="css/home-responsive.css">
			<!-- LOAD JQUERY LIBRARY -->
			<script type="text/javascript" src="js/jquery.js"></script>
			<script type="text/javascript">
			window.RS_MODULES = window.RS_MODULES || {};
			window.RS_MODULES.modules = window.RS_MODULES.modules || {};
			window.RS_MODULES.waiting = window.RS_MODULES.waiting || [];
			window.RS_MODULES.defered = true;
			window.RS_MODULES.moduleWaiting = window.RS_MODULES.moduleWaiting || {};
			window.RS_MODULES.type = 'compiled';
		</script>
					<script type="text/javascript" src="js/rbtools.min.js"></script>
			<script type="text/javascript" src="js/rs6.min.js"></script>
			
			<script type="text/javascript">function setREVStartSize(e){
			//window.requestAnimationFrame(function() {				 
				window.RSIW = window.RSIW===undefined ? window.innerWidth : window.RSIW;	
				window.RSIH = window.RSIH===undefined ? window.innerHeight : window.RSIH;	
				try {								
					var pw = document.getElementById(e.c).parentNode.offsetWidth,
						newh;
					pw = pw===0 || isNaN(pw) ? window.RSIW : pw;
					e.tabw = e.tabw===undefined ? 0 : parseInt(e.tabw);
					e.thumbw = e.thumbw===undefined ? 0 : parseInt(e.thumbw);
					e.tabh = e.tabh===undefined ? 0 : parseInt(e.tabh);
					e.thumbh = e.thumbh===undefined ? 0 : parseInt(e.thumbh);
					e.tabhide = e.tabhide===undefined ? 0 : parseInt(e.tabhide);
					e.thumbhide = e.thumbhide===undefined ? 0 : parseInt(e.thumbhide);
					e.mh = e.mh===undefined || e.mh=="" || e.mh==="auto" ? 0 : parseInt(e.mh,0);		
					if(e.layout==="fullscreen" || e.l==="fullscreen") 						
						newh = Math.max(e.mh,window.RSIH);					
					else{					
						e.gw = Array.isArray(e.gw) ? e.gw : [e.gw];
						for (var i in e.rl) if (e.gw[i]===undefined || e.gw[i]===0) e.gw[i] = e.gw[i-1];					
						e.gh = e.el===undefined || e.el==="" || (Array.isArray(e.el) && e.el.length==0)? e.gh : e.el;
						e.gh = Array.isArray(e.gh) ? e.gh : [e.gh];
						for (var i in e.rl) if (e.gh[i]===undefined || e.gh[i]===0) e.gh[i] = e.gh[i-1];
											
						var nl = new Array(e.rl.length),
							ix = 0,						
							sl;					
						e.tabw = e.tabhide>=pw ? 0 : e.tabw;
						e.thumbw = e.thumbhide>=pw ? 0 : e.thumbw;
						e.tabh = e.tabhide>=pw ? 0 : e.tabh;
						e.thumbh = e.thumbhide>=pw ? 0 : e.thumbh;					
						for (var i in e.rl) nl[i] = e.rl[i]<window.RSIW ? 0 : e.rl[i];
						sl = nl[0];									
						for (var i in nl) if (sl>nl[i] && nl[i]>0) { sl = nl[i]; ix=i;}															
						var m = pw>(e.gw[ix]+e.tabw+e.thumbw) ? 1 : (pw-(e.tabw+e.thumbw)) / (e.gw[ix]);					
						newh =  (e.gh[ix] * m) + (e.tabh + e.thumbh);
					}
					var el = document.getElementById(e.c);
					if (el!==null && el) el.style.height = newh+"px";					
					el = document.getElementById(e.c+"_wrapper");
					if (el!==null && el) {
						el.style.height = newh+"px";
						el.style.display = "block";
					}
				} catch(e){
					console.log("Failure at Presize of Slider:" + e)
				}					   
			//});
		  };</script>
		  
		</head>
		
		<body>
		<?php
		require_once("include/nav.php");
		require_once("include/slider.php");
		require_once("package/packages.php");
		?>
			<!-- section two -->
			<section class="mt-5 section-two">
				<div class="section-two-bg">
					<img class="section-two-bg-img" src="assets/section-two-bg.png">
				</div>
				<div class="section-two-box-color p-5">
					<div class="container-fluid">
						<div class="row text-center pb-5">
							<div class="col-12 mt-5 mb-3 ">
								<h2 class="section-two-heading">Custom Web n Logo Design Company in <b>Houston, TX </b></h2>
								<p>We provide complete digital branding and marketing service to bring your business to online customers.</p>
							</div>
							<div class="col-xl-3 col-lg-6 p-4">
							<div class="section-two-box section-two-box1">
								<img src="assets/section-two-icon1.png">
								<h5 class="pt-3"><b>Custom Logo Design in Houston, TX</b></h5>
								<p>Your Logo is microcosm of everything that your company represents. Our imaginative artists can make your business a customized unique logo that will make it symbolic for years.</p>
							</div>
							</div>
							<div class="col-xl-3 col-lg-6 p-4">
							<div class="section-two-box section-two-box2">
								<img src="assets/section-two-icon2.png">
								<h5 class="pt-3"><b>Custom Branding Service in Houston, TX</b></h5>
								<p>Logos, Business Cards, Letterheads, Websites, Brochures, Profiles, Social Media, and Blogs. We are one for all and all for one.</p>
							</div>
							</div>
							<div class="col-xl-3 col-lg-6 p-4">
							<div class="section-two-box section-two-box3">
								<img src="assets/section-two-icon3.png">
								<h5 class="pt-3"><b>Result Oriented Digital Marketing</b></h5>
								<p>We offer Digital and Creative Marketing services to build your public image and attract customers to your brand.</p>
							</div>
							</div>
							<div class="col-xl-3 col-lg-6 p-4">
							<div class="section-two-box section-two-box4">
								<img src="assets/section-two-icon4.png">
								<h5 class="pt-3"><b>Digital Marketing & Creative Marketing</b></h5>
								<p>We offer Digital and Creative Marketing services to build your public image and attract customers to your brand. </p>
							</div>
							</div>
						</div>
					</div>
				</div>
					<div class="services-bottom-shape">
						<div class="section-two-arrow text-center">
								<i class="fa fa-long-arrow-down" aria-hidden="true"></i>
						</div>
					</div>
			</section>
			<!-- section two end-->


			<!-- section three -->
			<section class="section-three">
				<div class="container-fluid">
				<h2><b>Showcase</b></h2>
				  <p>A Glimpse of What we can Accomplish for you!</p>
				 <div id="tab-btn"></div>
				    <div id="gallery">
				  	
				      <a href="assets/logo/1.jpg" target="_blank"><img src="assets/logo/1.jpg" data-tags="LOGO" alt=""/></a>
				      <a href="assets/logo/2.jpg" target="_blank"><img src="assets/logo/2.jpg" data-tags="LOGO" alt=""/></a>
				      <a href="assets/logo/3.jpg" target="_blank"><img src="assets/logo/3.jpg" data-tags="LOGO" alt=""/></a>
				      <a href="assets/logo/4.jpg" target="_blank"><img src="assets/logo/4.jpg" data-tags="LOGO" alt=""/></a>
				      <a href="assets/logo/5.jpg" target="_blank"><img src="assets/logo/5.jpg" data-tags="LOGO" alt=""/></a>
				      <a href="assets/logo/6.png" target="_blank"><img src="assets/logo/6.png" data-tags="LOGO" alt=""/></a>
				      <a href="assets/logo/7.jpg" target="_blank"><img src="assets/logo/7.jpg" data-tags="LOGO" alt=""/></a>
				      <a href="assets/logo/8.jpg" target="_blank"><img src="assets/logo/8.jpg" data-tags="LOGO" alt=""/></a>
				      <a href="assets/logo/9.jpg" target="_blank"><img src="assets/logo/9.jpg" data-tags="LOGO" alt=""/></a>

				      <a href="assets/website/1.jpg" target="_blank"><img src="assets/website/1.jpg" style="display: none;" data-tags="WEBSITE" alt=""/></a>
				      <a href="assets/website/2.png" target="_blank"><img src="assets/website/2.png" style="display: none;" data-tags="WEBSITE" alt=""/></a>
				      <a href="assets/website/3.jpg" target="_blank"><img src="assets/website/3.jpg" style="display: none;" data-tags="WEBSITE" alt=""/></a>
				      <a href="assets/website/4.jpg" target="_blank"><img src="assets/website/4.jpg" style="display: none;" data-tags="WEBSITE" alt=""/></a>
				      <a href="assets/website/5.png" target="_blank"><img src="assets/website/5.png" style="display: none;" data-tags="WEBSITE" alt=""/></a>
				      <a href="assets/website/6.jpg" target="_blank"><img src="assets/website/6.jpg" style="display: none;" data-tags="WEBSITE" alt=""/></a>
				      <a href="assets/website/7.jpg" target="_blank"><img src="assets/website/7.jpg" style="display: none;" data-tags="WEBSITE" alt=""/></a>
				      <a href="assets/website/8.png" target="_blank"><img src="assets/website/8.png" style="display: none;" data-tags="WEBSITE" alt=""/></a>

				      <a href="assets/ecommerce/1.jpg" target="_blank"><img src="assets/ecommerce/1.jpg" style="display: none;" data-tags="E-COMMERCE" alt=""/></a>
				      <a href="assets/ecommerce/2.jpg" target="_blank"><img src="assets/ecommerce/2.jpg" style="display: none;" data-tags="E-COMMERCE" alt=""/></a>
				      <a href="assets/ecommerce/3.jpg" target="_blank"><img src="assets/ecommerce/3.jpg" style="display: none;" data-tags="E-COMMERCE" alt=""/></a>
				      <a href="assets/ecommerce/4.jpg" target="_blank"><img src="assets/ecommerce/4.jpg" style="display: none;" data-tags="E-COMMERCE" alt=""/></a>
				      <a href="assets/ecommerce/5.jpg" target="_blank"><img src="assets/ecommerce/5.jpg" style="display: none;" data-tags="E-COMMERCE" alt=""/></a>
				      <a href="assets/ecommerce/6.png" target="_blank"><img src="assets/ecommerce/6.png" style="display: none;" data-tags="E-COMMERCE" alt=""/></a>
				      <a href="assets/ecommerce/7.jpg" target="_blank"><img src="assets/ecommerce/7.jpg" style="display: none;" data-tags="E-COMMERCE" alt=""/></a>
				      <a href="assets/ecommerce/8.jpg" target="_blank"><img src="assets/ecommerce/8.jpg" style="display: none;" data-tags="E-COMMERCE" alt=""/></a>
				      <a href="assets/ecommerce/9.jpg" target="_blank"><img src="assets/ecommerce/9.jpg" style="display: none;" data-tags="E-COMMERCE" alt=""/></a>
				      <a href="assets/ecommerce/10.jpg" target="_blank"><img src="assets/ecommerce/10.jpg" style="display: none;" data-tags="E-COMMERCE" alt=""/></a>


				    </div>
				</div>
			</section>
			<div class="section-three-end-btn text-center">
				<a class="btn section-three-btn popupBox" data-toggle="modal" data-target="getQuote"  href="javascript:">LET'S GET STARTED</a>
			</div>
			<!--section three end -->
			<!-- section one -->
			<section class="mt-5 pg whyUs"  data-aos="fade-up">
				<div class="container-fluid section-one">
					<div class="row">
						<div class="col-1 d-none d-xl-block">
							<div class="about-heading">ABOUT<span>US</span></div>
						</div>
						<div class="col-xl-5 col-lg-6 mt-5">
							<img width="100%" src="assets/section-one.png">
						</div>
						<div class="col-xl-5 col-lg-6 mt-5">
							<div class="section-one-sec">
							<h3>Why Invest In SEO (Search Engine Optimization)?</h3>
							<div class="hr"></div>
							<p class="color-lightgray section-one-p">
								When it comes to websites, just making them is never enough. You can’t simply wait for random customers to wander to your website. You must pull them towards your company whenever they require a service that you can provide. A website built on strong SEO-optimized foundations will grab the attention of netizens and make sure that your website is at the top of the list whenever anyone searches for a service provider, ultimately growing your business. Operating throughout Houston, SEO services of the highest order can be found with CustomWebnLogoDesigns.  
								<br>						
								You cannot wait for the algorithm to randomly bless your website and elevate its status.  
							</p>
							</div>
							<div class="row section-one-box">
								
								<div class="col-xl-4 col-lg-6 col-sm-4">
								<center>
								<div class="section-one-box1">
									<img class="box-icon" src="assets/box-icon1.png">
								</div>
								<p>Invest in SEO<img class="section-one-hr" src="assets/hr.png"></p>
								</center>
								</div>

								<div class="col-xl-4 col-lg-6 col-sm-4">
								<center>
								<div class="section-one-box2">
									<img class="box-icon" src="assets/box-icon2.png">
								</div>
								<p>Top all Lists<img class="section-one-hr" src="assets/hr.png"></p>
								</center>
								</div>

								<div class="col-xl-4 col-lg-12 col-sm-4">
								<center>
								<div class="section-one-box3 text-center">
									<img class="box-icon" src="assets/box-icon3.png">
								</div>
								<p>Generate Traffic and Customers!<img class="section-one-hr" src="assets/hr.png"></p>
								
								</center>
								</div>
							</div>
						</div>
						<div class="col-1 d-none d-xl-block">
							<img width="90%" src="assets/section-one-icon.png">
						</div>
						<div class="col-12 text-center section-one-bottom">
							CUSTOM WEB & LOGO
						</div>
					</div>
				</div>
			</section>
			<!-- section one end-->
			<?php
				require_once("include/contact.php");
				require_once("include/key.php");
			?>

			<!--why choose-->
			<section class="why-choose">
				<div class="container-fluid text-center">
				<h2>Why <b>Choose us</b></h2>
				<div class="row">
					<div class="col-xl-3 col-md-6">
						<div class="bg-image">
							<img class="why-choose-img" src="assets/why-choose/image1.png">
							<div class="why-choose-icon">
							<img src="assets/box-icon3.png">
							</div>
							<div class="why-choose-p">
								<h4>Quality!</h4>
								<p>If you are looking for high-quality work done with impeccable professionalism then CustomWebnLogoDesign is the brand you want on your side.</p>
							</div>
						</div>
						<div class="why-choose-border why-choose-border-single"></div>
					</div>
					<div class="col-xl-3 col-md-6">
						<div class="bg-image">
							<img class="why-choose-img" src="assets/why-choose/image2.png">
							<div class="why-choose-icon">
							<img src="assets/box-icon1.png">
							</div>
							<div class="why-choose-p">
								<h4>Innovative!</h4>
								<p>We are all students of life and our firm learns, adapts, and grows with time. Our work is performed through modern innovative practices that solidify your brand as timeless.</p>
							</div>
						</div>
						<div class="why-choose-border why-choose-border-single"></div>
					</div>
					<div class="col-xl-3 col-md-6">
						<div class="bg-image">
							<img class="why-choose-img" src="assets/why-choose/image3.png">
							<div class="why-choose-icon">
							<img src="assets/box-icon2.png">
							</div>
							<div class="why-choose-p">
								<h4>Teamwork!</h4>
								<p>Our highly coordinated, compatible, and proficient team of developers, managers, writers all work together with the utmost efficiency to deliver peak performance to clients.</p>
							</div>
						</div>
						<div class="why-choose-border why-choose-border-single"></div>
					</div>
					<div class="col-xl-3 col-md-6">
						<div class="bg-image">
							<img class="why-choose-img" src="assets/why-choose/image4.png">
							<div class="why-choose-icon">
							<img src="assets/box-icon4.png">
							</div>
							<div class="why-choose-p">
								<h4>Supportive!</h4>
								<p>One for all and all for one, we believe in achieving 100% customer satisfaction and ensure that no matter the case everything is done in accordance with your approvals. </p>
							</div>
						</div>
						<div class="why-choose-border why-choose-border-single"></div>
					</div>
				</div>
				<div class="why-choose-border  why-choose-border-full"></div>
				</div>
			</section>
			<!--why choose end-->
			<?php
				require_once("include/client.php");
			?>
			<!--section award -->
			<section class="section-award">
				<div class="container">
					<h4>Celebrated and Distinguished!</h4>
					<p>Throughout our commercial lifespan, we have toiled hard day and night to be awarded and venerated by the highest honors of our industry. We are proud to display our achievements throughout our many projects!</p>
					<div class="row">
						<div class="col-lg-3 col-6">
							<img src="assets/awards/image1.png">
						</div>
						<div class="col-lg-3 col-6">
							<img src="assets/awards/image2.png">
						</div>
						<div class="col-lg-3 col-6">
							<img src="assets/awards/image3.png">
						</div>
						<div class="col-lg-3 col-6">
							<img src="assets/awards/image4.png">
						</div>
					</div>
				</div>
			</section>
			<!--section award end -->
			<!--subscribe-->
<form method="post" id="sub">
			<section class="subscribe container-fluid">
				<div class="container">
					<div class="row">
						<div class="col-xl-5 text-center">
							<h3>Looking for the finest web development company, Houston, Texas? Here we are.</h3>
						</div>
						<div class="col-xl-7">
							<div class="input-container">
							    <i class="fa fa-envelope-o sub-icon" aria-hidden="true"></i>
							    <input name="email" class="input-field" type="email" placeholder="Enter Email Address..." required>
							    <div class="sub-btn-back">
							    <input  class="sub-btn" type="submit" name="" value="LET'S START"></div>
							   
						  	</div>

						</div>
					</div>
				</div>
			</section>

			 </form>
			<!--subscribe end-->
			<?php
		require_once("include/footer.php");
		?>
	<script src="inner/bootstrap/4.0.0/js/bootstrap.min.js"></script>

<!-- Forms validation -->
<script src="inner/js/form_validator.min.js"></script>
<script>
    
    // validation Initializing
    $.validate({});
    
    // Captcha Key Initializing
    // var captchaKey = ""

</script>
		<!--plugin -->
	<script type="text/javascript" src="js/plugin/owlcarousel/owl.carousel.min.js"></script>
	<script type="text/javascript" src="js/plugin/owlcarousel/custom.js"></script>

	<!-- custom -->
	<script src="js/myjs.js"></script>
	<script src="js/package.js"></script>
	<script>
    function order_id(id)
    {
    	$(".loading").removeClass("d-none");
        var orderid = id;
        $.ajax({  
        type: 'POST',  
        url: 'function/orderscript', 
        data: { orderid : orderid},
        success: function(data) {
        	$(".loading").addClass("d-none");
        	if(data=="done")
            {
            	window.location="order/order-now";
            }
            else
            {
                alert("Update/Change your browser");
            }
    }
    });
    }
    //quote form
    $(document).on("submit",".leadForm" , function(e){
        e.preventDefault();
        var country = $(this).parent().find('.selected-flag').attr("title");
        $(".loading").removeClass("d-none");
        $.ajax({  
          type: 'POST',  
          url: 'function/form?quote='+country, 
          data: $(this).serialize(),
          success: function(data) {
            $(".loading").addClass("d-none");
              alert(data);
            }
          });
      });
    $(document).on("submit","#sub" , function(e){
        e.preventDefault();
        $(".loading").removeClass("d-none");
        $.ajax({  
          type: 'POST',  
          url: 'function/form?sub', 
          data: $(this).serialize(),
          success: function(data) {
            $(".loading").addClass("d-none");
              alert(data);
            }
          });
      });
</script>
	</body>
	</html>
		