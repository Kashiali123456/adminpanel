<!DOCTYPE html>
<html>
  <head>
    <title>Privacy Policy - Freelance</title>

    <link href="css/style.css" rel="stylesheet">
    <link href="css/custom-scroller.css" rel="stylesheet">
    <link href="css/style-web.css" rel="stylesheet">
    <link href="css/style-responsive.css" rel="stylesheet">
    <?php
            require_once("orderinclude/head.php");
        ?>
  </head>
  <body class="home-page">
    <?php
            require_once("orderinclude/nav.php");
        ?>
<section class="main-privacy">
    <div class="container">
        <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12 privacy">
                <h3>Terms and conditions</h3>
                <p>Please read our Terms and Conditions (further as Agreement) containing important information regarding the use of the website and provided services. By entering the website, signing up, placing an Order or using any of the presented services, you agree to enter into a legally binding agreement with the Company.</p>


            <div class="term-text">
                  
                    <p>The Company reserves the right to change, amend, revise and modify any or all provisions of this Agreement.</p>
                    <p>You agree to read this Agreement before each use of the present website. In case you do not agree with the Agreement, do not use the website and leave it when possible.</p>
                    <p>If you continue using the services after the change and publishing of the Agreement, you agree to its updated version.</p>
                    <p>In case you want to terminate the given Agreement, please request to remove your account from the database and cease visiting and using the website.</p>
                    <p>The collection, processing and transfer of the personal data is regulated by the Privacy Policy, including the Terms of Cookies use as a part of the given Agreement.</p>
                </div>

                 <div class="term-text">
                  <h3>DEFINITIONS</h3>
                    <h3>Vocabulary</h3>
                    <p>1.1. 'Agreement' refers to these Terms and Conditions.</p>
                    <p>1.2. 'Company' means the entity that provides independent research and writing services to Clients according to the defined terms laid out in this Agreement.</p>
                    <p>1.3. 'Website' stands for this website that is open for free visual review, operated by the Company, publicly available on the Internet at https://www.thedesignsavenue.com/</p>
                    <p>1.4. 'Resume Writer' is the person, who has agreed to work with the Company on a freelance basis to provide career services under the Company's terms.</p>
                    <p>1.5. 'You', 'Client', 'User' is the person who uses the website and/or the person who places an Order with the Company to obtain the Product according to his or her requirements and is governed by the defined terms and conditions laid out in this Agreement.</p>
                    <p>1.6. 'Order' is an electronic request of a paid service from the Client for a particular Product and/or service.</p>
                    <p>1.7. 'Order Status' defines Order progress on a particular stage.</p>
                    <p>1.8. 'Product' is a document in an electronic format that is the final result of Order completion.</p>
                    <p>1.9. 'Product Revision' is an edited version of the original Product initialized by Client.</p>
                    <p>1.10. 'Support Team or Support' is the part of the Company's organizational structure with the mission to assist and coordinate the Order process.</p>
                    <p>1.11. 'Quality Assurance Department' signifies the part of the Company's organizational structure with the mission to guard and evaluate the quality of Product and service provided.</p>
                    <p>1.12. 'Messaging System' is an interactive feature that ensures communication between the Client and Support/ Resume Writer.</p>
                    <p>1.13. 'Job Interview' is a call, email communication, in-person meeting, or any other means of communication with the potential employer after you have sent the resume or CV.</p>
                </div>

                 <div class="term-text">
                    <h3>2. Nature of Product and Terms of Use </h3>
                    <p>2.1. The Company offers a service which allows Client to find the qualified resume-writing professionals to provide career services to the Client as unique recommendations intended to assist the Client in his job search. Thus, it is understood that Company makes no guarantees regarding the successful interview walkthrough by the Client as a result. The purpose of this Agreement is to provide Clients with Product or services in accordance with the instructions of the Client. All that the Company provides, is intended only for the purpose of the career of the Client in accordance with his instructions. The Company is also not responsible for failure on the part of the Client to successfully obtain a desired job, with the help of the Product, or improper use of the Product.</p>
                    <p>2.2. LinkedIn® profile writing service means that the Client will receive a fully developed profile information in a .doc/.docx format. Our Resume Writers are not authorized to access the Clients' LinkedIn® accounts. It is an obligation of the Clients to transfer the provided information to their accounts.</p>
                    <p>2.3. The Company does not ask the Client to specify their age as well as it cannot determine the exact age of persons entering the website. The usage of the Company's services by persons under 16 years old is acceptable only with the consent of parents or legal guardians. If you are a parent or a legal guardian and you have any reason to believe that your child or ward has provided their personal data to the Company without your consent, please contact us at info@thedesignsavenue.com.</p>
                    <p>Placing an Order using false information, including an Order made for another person and a person under 16 years old with no prior consent of a parent or legal guardian, is a violation of the terms of the giver Agreement.</p>
                </div>


                 <div class="term-text">
                    <h3>3. Order Process </h3>
                    <p>3.1 Placing an Order. When filling in an Order form, it is the sole responsibility of the Client to register using a valid email address and to provide a correct phone number where the Client can be reached (preferably both - home and mobile). There may be multiple occasions during Order preparation when establishing contact with the Client is crucial. Failure to provide a valid email address or a correct phone number may affect Order completion and will result in a violation of the terms and conditions of this Agreement. This may lead to forfeiture of any claim to the implied warranty or guarantee by the Client.</p>
                    <p>While using the account, the Client obliged to:</p>
                    <ul>
                      <li>While using the account, the Client obliged to:</li>
                      <li>Inform the Support right away in case of disclosure or possible disclosure of the password necessary to log in the account.</li>
                    </ul>
                    <p>The Client is accountable for every action made on his account until they close it or report its misuse by third parties.</p>
                    <p>The direct communication over the phone between the Client and the Resume Writer is prohibited by the Company. For that purpose, the Client is welcome to use the numerous interactive features created by the Company. For any questions and concerns, the Client can also contact a qualified Support Team available 24/7.</p>
                </div>

                 <div class="term-text">
                    <h3>3.2. Provided information </h3>
                    <p>Information provided by the Client in Order description and in additional files needed for Order completion immediately becomes visible for the Resume Writers once Order is paid. The Company is not responsible for the information voluntarily disclosed by the Client when placing an Order and highly encourages the Client to avoid including any personal or billing information (i.e. Client's phone number, email address etc.) as well as disclosing the Client's identity when communicating with the Resume Writer through the Messaging System.</p>
                </div>

                 <div class="term-text">
                    <h3>Discounts</h3>
                    <p>A discount code cannot be used after the Order is placed. The Company is not obliged to replace the Order or compensate the difference in case the discount code is not used while placing the Order. Thus, the Client must be attentive and precise when filling the form and placing the Order.</p>
                </div>

                 <div class="term-text">
                    <h3>Instructions</h3>
                    <p>As far as the Company works based on the Client's instructions, the latter must be full and precise. The Client is obliged to either fill in a survey with the information needed for Product Completion or provide an old Resume or CV for reference after the Order placement. The Client may also use both options to send all the necessary details.</p>
                    <p>If the Client fails to provide the necessary information within the reasonable for the Order completion time period, the Company cannot fulfill any implied warranty or guarantee, and it shall not be held responsible.</p>
                    <p>The Client is advised that once the Order is completed, any revision request must only be based on the initial requirements as well as description of the original Order. Any changes from the initial instructions of the Order will be considered as 'editing' which is an additional service of the Company. In this case, the Company will not conduct any free revision request that is different or deviates from the original Order requirements/description.</p>
                    <p>Any additional instructions and requests must be sent before a Resume Writer is assigned to the Order.</p>
                    <p>Failure to meet this requirement will result in violation of the given Agreement and forfeiture of any claim to the implied warranty or guarantee.</p>
                </div>

                 <div class="term-text">
                    <h3>3.5. Sources</h3>
                    <p>The Resume Writer has the right to use all the information provided by the Client. Also, the Resume Writer can use the Internet to understand better the instructions of the Client, the specifications of the Order, and comply the Order with the requirements of the job the Client want to apply, in case the Client has not provided this information himself.</p>
                </div>

                 <div class="term-text">
                    <h3>3.6. Messaging System</h3>
                    <p>The Messaging System is an easy and convenient way to communicate. The Client should check messages for any updates from the Support Team or from the Resume Writer. The Client should also promptly address any questions, concerns or give additional instructions using this interactive feature. Failure or neglect to check the Messaging System shall not be sufficient ground for a refund of services rendered. If the Client does not know how to use the Messaging System, the Client may contact the Support Team at any time for assistance or instruction by our toll free phone number or send an email.</p>
                </div>

                 <div class="term-text">
                    <h3>3.7. Incorrect Order Placement</h3>
                    <p>The Company reserves the right not to process or to resubmit the Client's Order in the event that the details indicated are inconsistent to or do not match the Order's original description. Failure to provide the correct description or choosing the wrong Product, deadline extension requests may require additional payments. Please note this is done by the Company only so that it may properly process the Client's Order and have the best possible Resume Writer to complete the Client's Order. The Client will always be contacted to approve any additional charges or requests.</p>
                </div>

                 <div class="term-text">
                    <h3>3.8. Tracking Order Progress</h3>
                    <p>The Client is highly encouraged to stay in touch with the Support Team/Resume Writer and to monitor Order Progress through the Client's personal account on the web site. Possible statuses of the Order are:</p>
                    <ul>
                      <li> <b>Order is not paid </b>- the Order is already registered within the Company's system but the Client should proceed with the payment before the Company starts working on it.</li>
                      <li> <b>Research has been started </b>- the Order is paid and made available to appropriate Resume writers.</li>
                      <li> <b>Preparing</b> - a Resume Writer is working on your Order.</li>
                      <li><b> Order is completed</b> - the Product has been uploaded for the Client's review. The Client is welcome to download it from the Client's personal account on the web site or email that is automatically sent to the Client's email address.</li>
                      
                      <li><b> Returned for revision </b> - Resume Writer is revising the Product according to Client's instructions.</li>
                      <li><b> Hold </b> - the Order is put on hold by the Support Team and the Resume Writer has temporarily stopped working on it. The Client is advised to visit Messaging board on the personal profile for detailed information or to contact the Support Team.</li>
                      <li><b> Order is canceled </b> - t• Order is canceled.</li>
                    </ul>
                </div>


                 <div class="term-text">
                    <h3>4. Delivery/Downloading Policy </h3>
                    <p>4.1. Resume Distribution. Resume Distribution service means that the Company will send out the Client's resume, CV and Cover Letter to the employment agencies and staffing services of the Company's choice all over the USA. Resume Distribution can be performed only after the Client fills in Resume Distribution form and confirms the distribution launch. Failure to meet this requirement will result in a violation of the given Agreement and forfeiture of any claim to the implied warranty or guarantee.</p>
                    <p>4.2. The Company strives for the highest level of satisfaction available. However, the Company cannot and will not be held liable or responsible for any type of delivery issues resulting from problems such as spam filters, incorrect email, lack of internet access or general neglect, among others, which are beyond its control and/or without its fault. The Support Team is available 24 hours a day to assist the Client with any delivery problems of the Order. However, it is the sole responsibility of the Client to provide the correct contact information to the Company.</p>
                    <p>4.3. In case of timely delivery of the Product, the Company will not be responsible for failure of the Client to download the Product. Please note that the Client will still be billed for the service rendered and no refund is guaranteed at this point in Order to pay the Resume Writer for the work done.</p>
                </div>


                 <div class="term-text">
                    <h3>5. Termination </h3>
                    <p>5.1. The Company reserves the right to cancel any paid Order at its own determination or decision in case there is lack of cooperation/communication from the Client's side that affects Order completion or a suspicion by the Company that the Client is engaged in a fraudulent activity. The Company does not guarantee reimbursement in the circumstances described above. Each case is analyzed separately and final decision depends on the number of factors. The Company shall have sole discretion to take action based on the particular circumstances of each case.</p>
                </div>


                <div class="term-text">
                    <h3>6. Revision policy </h3>
                    <p>6.1. To ensure a high level of Client service and guarantee the Clients' satisfaction with the Product, we provide a free revision service/option. The Client can request a free revision within 30 (thirty) days after his/her Order initial deadline. In case the Client asks for revision on the 30th day after the initial deadline, we guarantee to revise this Order during 5 days.</p>
                    <p>6.2. If the Client has missed the policy deadline, but still needs to get his Order revised, the Client may place the new Order for editing purposes. </p>
                    <p>6.3. Quality Assurance Department of the Company reserves the right to limit the number of revisions or decline revision requests in cases such as, but not limited to: changes in initial Order details; unreasonable return of the product; taking advantage of Resume Writer and obvious abuse of revision option.</p>
                    <p>6.4. If revision request violates original instructions, the Quality Assurance Department has the right to decline it. If request falls within mentioned guidelines, the Company will happily revise the Client's Order to meet the initial requirements free of charge.</p>
                </div>

                 <div class="term-text">
                    <h3>7. Satisfaction Guarantee </h3>
                    <p>7.1. Should the customer not receive a Job Interview request in the 30 days following completion of the Order, the company will make free revisions within 5 days per client's request?</p>
                    <p>7.2. If the Client has missed the policy deadline, but still needs to get his Order revised, the Client may place the new Order for editing purposes. </p>
                    <p>7.3. If the Client needs to cancel an Order, it may be made at any time prior to the completion of the Order.</p>
                    <p>7.4. All refunds and cancellations should be communicated and expressed in writing by using the Order Messaging System or by emailing the Support Team. In the unlikely event that the Client is not satisfied with the Product or receive the Product after the specified deadline, the Client may request a partial or full refund. It is the sole discretion of the Company to approve or disapprove any request on an individual case to case basis.</p>
                    <p>7.5. In case of a refund request due to bad quality of the Product, the Client must provide strong reasons, and examples to back up the claim for refund. Only after an extended list of violations is provided, will the request for refund be forwarded to the Quality Assurance Department for further investigation and refund request approval.</p>
                    <p>7.6. If the Client has not asked the revision of the Product within 30 days after Order initial deadline and request for a refund came after this term, it is to be assumed that the Client is satisfied with the Product and the Client will not be eligible for any refunded amount.</p>
                </div>
                
                 <div class="term-text">
                    <h3>8. Promotional Materials </h3>
                    <p>8.1. The Company reserves the right to contact the Clients by email regarding new services, discounts, special offers and any other information that the Company may deem useful for the Clients.</p>
                    <p>8.2. The Client consents to receive emails and other forms of electronic communications including but not limited to push notifications, SMS from the Company.</p>
                    <p>8.3. The Client can opt-out of further receiving any commercial and marketing emails via the link included to these emails. In case of any problems with receiving such emails, the Client can message us at info@thedesignsavenue.com.</p>
                </div>

                <div class="term-text">
                    <h3>9. Waiver of Breach </h3>
                    <p>9.1. No waiver by the Company of any breach of this Agreement by the Client shall be held to be a waiver of any other or subsequent breach. All remedies afforded in this Agreement shall be taken and construed as cumulative, that is, in addition to every other remedy provided herein or by law.</p>
                    <p>9.2. The failure of the Company to insist on a strict performance of any of the terms and conditions of this Agreement shall be deemed a waiver of the rights or remedies that the Company may have regarding that specific instance only, and shall not be deemed a waiver of any subsequent breach of default in any terms and conditions.</p>
                </div>

                <div class="term-text">
                    <h3>10. Amendments </h3>
                    <p>10.1. The Company reserves the right to modify, amend, revise or otherwise change any and all provisions of this Agreement. The Client expressly agrees to be bound by any subsequent modification, amendment, revision or changes as contemplated herein, by the continued rendition of services by the Company. It shall be the obligation of the Client to review this Agreement for changes from time to time, since any changes are reflected in this section of the website.</p>
                </div>

                <div class="term-text">
                    <h3>11. Entire Agreement  </h3>
                    <p>11.1. The given Agreement, including the Privacy Policy along with the Terms of Cookies Use, contains the entire stipulations between the Client and the Company, and no statements, promises, or inducements made by either party or agent of either party that are inconsistent herein shall be valid or binding, unless expressly authorized under this Agreement. This Agreement may not be enlarged, modified, or altered except in writing signed by the parties and indorsed on this Agreement. This Agreement shall supersede all previous communications, representations, or agreements, either verbal or written, between the Client and the Company.</p>
                </div>

                <div class="term-text">
                    <h3>12. Severability  </h3>
                    <p>12.1. It is understood and agreed by the Client that if any part, term, or provision of this Agreement is held by the courts to be illegal or in conflict with any law of the state where made, the validity of the remaining portions or provisions shall not be affected, and the rights and obligations of the Client shall be construed and enforced as if the Agreement did not contain the particular part, term, or provision held to be invalid.</p>
                </div>

                <div class="term-text">
                    <h3>13. Law Governing </h3>
                    <p>13.1. It is mutually understood and agreed that this Agreement shall be governed by the laws of the place where the Company holds its principal place of business, both as to interpretation and performance, or in any other place at the determination of the Company.</p>
                </div>

                <div class="term-text">
                    <h3>14. Place of Suit  </h3>
                    <p>14.1. Any action or other judicial proceeding for the enforcement of this Agreement or any of its provisions shall be instituted in the courts of competent jurisdiction in the place where the Company holds its principal place of business or in any other place at the determination of the Company.</p>
                </div>

                <div class="term-text">
                    <h3>15. Termination of the Use of the Service </h3>
                    <p>15.1. In case the Client wants to terminate the Agreement at any time, it can be done by sending the request to delete the account directly to info@thedesignsavenue.com</p>
                </div>

                
            </div>


        </div>
    </div>
</section>
<?php
  require_once("orderinclude/footer.php");
?>
</body>
</html>
