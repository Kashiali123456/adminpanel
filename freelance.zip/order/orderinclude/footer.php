<footer>
  <div class="container">
    <div class="row">
      <div class="col-md-6">
        <p>&copy; Copyright 2021.  Custom Web N Logo Designs All Right Reserved.</p>
      </div>
      <div class="col-md-6">
        <p class="text-right">
          <a href="privacy-policy" target="_blank">Privacy Policy</a> | <a href="terms-conditions"
            target="_blank">Terms &
          Conditions</a>
        </p>
      </div>
    </div>
  </div>
</footer>