<?php
  require_once("../admin_panel/connection.php");
?>				
			<meta charset="utf-8">
			<meta http-equiv="X-UA-Compatible" content="IE=edge">
			<meta name="viewport" content="width=device-width, initial-scale=1">
      <link rel="shortcut icon" type="image/x-icon" href="../assets/fav.ico">
			<link rel="stylesheet" href="../inner/bootstrap/4.0.0/css/bootstrap.min.css">
			<link rel="stylesheet" type="text/css" href="../fonts/pe-icon-7-stroke/css/pe-icon-7-stroke.css">
			<link rel="stylesheet" type="text/css" href="../fonts/font-awesome/css/font-awesome.min.css">
			<link href="../css/jquerysctipttop.css" rel="stylesheet" type="text/css">
        <!-- custom -->
            <link rel="stylesheet" type="text/css" href="../css/style.css">
            <link rel="stylesheet" type="text/css" href="../css/home-responsive.css">
			<style>
          header
          {
            border-bottom: 2px solid #e4e4e4;
          }
        </style>